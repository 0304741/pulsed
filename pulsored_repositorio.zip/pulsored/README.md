# PulsoRed: analítica de demanda de red móvil

**Proyecto Integrador Capstone, Big Data Architecture & Strategy.**

PulsoRed es un pipeline distribuido en Google Cloud. Toma los 19.4 GB de actividad celular
de Milán del *Telecom Italia Big Data Challenge* y los convierte en tres productos de datos
para un operador móvil:

1. **Presión de capacidad** por cuadrante: dónde conviene ampliar la red primero.
2. **Ventanas de ahorro energético**: cuándo se pueden apagar capas de capacidad sin afectar el servicio.
3. **Detección de eventos**: qué horas y zonas tuvieron un tráfico atípico.

Además segmenta los cuadrantes por forma de uso (oficinas, residencial, ocio). Los
resultados se publican en un tablero ejecutivo interactivo.

| Si quieres… | Ve a |
|---|---|
| Replicar el proyecto en GCP, paso a paso y desde cero | [COMO_EMPEZAR.md](COMO_EMPEZAR.md) |
| Entender el código y las decisiones técnicas | [docs/EXPLICACION_CODIGO.md](docs/EXPLICACION_CODIGO.md) |
| Ver cómo se cumple cada requisito del enunciado | [docs/VERIFICACION_REQUISITOS.md](docs/VERIFICACION_REQUISITOS.md) |

---

## Las cuatro preguntas del CDO

| Pregunta | Respuesta |
|---|---|
| **¿Qué construimos?** | Un pipeline de extremo a extremo con tres productos: la ingesta con linaje, un lago por zonas, marts analíticos, una capa de servicio SQL y un tablero. |
| **¿Para qué?** | Hoy la red se dimensiona para el pico y opera igual a toda hora. La energía representa entre 20 y 40 % del OPEX de red (GSMA). Con datos por zona y hora se prioriza la inversión donde hay presión y se ahorra energía donde el tráfico lo permite. |
| **¿Cómo?** | Spark en un clúster Dataproc **efímero**, Parquet particionado en Cloud Storage, controles de calidad que detienen el flujo y MariaDB solo para agregados. Se sigue el principio KISS en cada elección. |
| **¿A quién beneficia?** | Planeación de red (dónde invertir), NOC y operación (cuándo aplicar modos de ahorro), Finanzas (OPEX de energía) y ESG. El ROI usa las horas de ahorro **medidas** y supuestos explícitos y editables. |

---

## Arquitectura

![Arquitectura](docs/arquitectura.png)

![Flujo por zonas](docs/flujo_zonas.png)

**Decisiones KISS ("un Tsuru confiable, no un Maserati"):**

- **Orquestación:** un **Workflow Template** de Dataproc en lugar de Composer o Airflow. Son 7 pasos en cadena, sin servidores encendidos todo el tiempo.
- **Clúster efímero:** se crea al iniciar la corrida y se borra al terminar. Solo se paga mientras procesa.
- **Formato:** Parquet + Snappy en lugar de Delta o Iceberg, porque el dato es histórico y no hay actualizaciones.
- **Sin streaming (Kafka):** la fuente es un histórico por lotes.
- **MariaDB solo como capa de servicio:** recibe cientos de miles de filas agregadas, nunca los 19.4 GB.
- **Tablero sin servidor:** es un HTML autocontenido generado con Python estándar, sin instalar nada.

---

## Estructura del repositorio

```
pulsored/
├── COMO_EMPEZAR.md              Guía de replicación paso a paso (desde Cloud Shell)
├── infra/
│   ├── 00_crear_infraestructura.sh   APIs, red, buckets, cuenta de servicio, secreto, VM, firewall (idempotente)
│   ├── 01_configurar_mariadb.sh      SSL, esquema, vistas, usuarios y supuestos de ROI en la VM
│   ├── 02_ejecutar_pipeline.sh       Arma el workflow según el perfil de clúster y lo ejecuta
│   ├── 03_prueba_escalabilidad.sh    Repite la carga con otro tamaño de clúster (sección 4.k)
│   ├── 04_restablecer_acceso_tablero.sh  Diagnostica "Access denied" y renueva la contraseña de lectura
│   ├── verificar_estado.sh           Lista de revisión: qué está listo y qué falta
│   └── workflow_pulsored.yaml        Plantilla del Workflow Template (7 pasos + clúster efímero)
├── ingest/
│   ├── lanzar_en_vm.sh               Lanza o consulta la descarga dentro de la VM
│   └── descargar_dataverse.sh        Dataverse → GCS con registro de uso, MD5 y manifiesto
├── jobs/                             Código PySpark (Dataproc 2.2, Spark 3.5)
│   ├── common.py                     Esquema, parámetros de negocio, rutas, métricas
│   ├── 01_raw_a_staging.py           Perfil de calidad, cuarentena, limpieza, Parquet por fecha
│   ├── 02_calidad.py                 Quality gate y catálogo de la cuadrícula
│   ├── 03_marts.py                   Serie horaria, perfiles, presión, ventanas, anomalías
│   ├── 04_segmentacion.py            K-Means (MLlib) sobre la forma del uso
│   ├── 05_benchmark.py               TSV contra Parquet y tamaño por zona del lago
│   ├── 06_reporte_visual.py          Reporte HTML con calidad, rendimiento y escalabilidad
│   └── 07_carga_mariadb.py           Publicación en MariaDB por JDBC (recarga idempotente)
├── sql/
│   ├── 01_ddl_mariadb.sql            13 tablas, usuarios con mínimo privilegio
│   ├── 02_vistas_tablero.sql         6 vistas de negocio
│   └── 03_kpis_documento.sql         Consultas Q0–Q10 con las cifras del documento
├── tablero/
│   ├── generar_tablero.sh            Genera el tablero leyendo MariaDB (desde Cloud Shell)
│   ├── generar_tablero.py            Generador (solo biblioteca estándar de Python)
│   ├── plantilla_tablero.html        Tablero: 6 pestañas, filtros, mapas, simulador de ROI
│   └── publicar_tablero.sh           Publica el tablero como enlace público (opcional)
├── tests/test_transformaciones.py    5 pruebas unitarias (pytest + Spark local)
├── tools/generar_muestra_sintetica.py  Datos SINTÉTICOS con defectos inyectados, solo para pruebas
├── docs/                             Explicación del código, verificación, diagramas
└── requirements-dev.txt              Dependencias para pruebas locales
```

---

## El pipeline en siete pasos

| Paso | Lee | Escribe | Qué hace y con qué técnica |
|---|---|---|---|
| **01 raw → staging** | 62 TSV (19.4 GB) | `staging/actividad_pais`, `staging/actividad_celda`, `staging/cuarentena`, `calidad/dq_raw` | Lee con esquema explícito, perfila la calidad por archivo en una sola agregación y pone en cuarentena las filas inválidas. Desduplica en dos pasos, convierte UTC a hora de Milán y escribe Parquet particionado por fecha. |
| **02 quality gate** | staging, GeoJSON | `calidad/dq_resultados`, `marts/dim_cuadricula` | Aplica 10 controles. Si falla uno **crítico**, termina con código 1 y el workflow se detiene antes de publicar. Calcula los centroides de la cuadrícula con funciones de orden superior de Spark SQL. |
| **03 marts** | staging | `marts/*` | Serie horaria densificada, perfil semanal típico (media y p95), índice de presión (percentil) y ventanas de ahorro (*gaps & islands*). Detecta anomalías con z robusto (mediana y MAD) y calcula la tendencia diaria. |
| **04 segmentación** | perfil semanal | `marts/cluster_*`, `cuadrante_enriquecido` | K-Means sobre 48 valores normalizados por la media de cada cuadrante, es decir, sobre la *forma* del uso. Elige k por silhouette. |
| **05 benchmark** | raw y staging | `calidad/benchmark`, `calidad/almacenamiento` | Ejecuta el mismo cálculo sobre TSV y sobre Parquet (agregación completa y consulta selectiva) y mide el factor de compresión. |
| **06 reporte** | marts, calidad | `reportes/reporte_pulsored.html` | Reporte ejecutivo con KPIs, mapas, ROI, calidad y comparación de rendimiento entre corridas. |
| **07 carga** | marts, calidad | MariaDB `pulsored` | Carga JDBC con `overwrite` + `truncate`, que conserva llaves e índices. El histórico de calidad se **anexa**. Va al final a propósito: si MariaDB falla, todo lo demás ya quedó en GCS. |

Cada job registra su duración y sus conteos en `calidad/metricas_ejecucion`, con la etiqueta de
la corrida (por ejemplo `8cores`). Eso es la evidencia de rendimiento y escalabilidad.
El detalle de cada paso, con fragmentos de código, está en
[docs/EXPLICACION_CODIGO.md](docs/EXPLICACION_CODIGO.md).

### Zonas del lago (`gs://PROYECTO-pulsored-lake`)

```
raw/        telecom/*.txt (inmutable) · grid/milano-grid.geojson · _manifiestos/ (MD5 y linaje)
staging/    actividad_pais/dt=… · actividad_celda/dt=… · cuarentena/
calidad/    dq_raw · dq_resultados(_por_dia) · metricas_ejecucion · benchmark · almacenamiento
marts/      serie_horaria/dt=… · perfil_semanal · presion_capacidad · ventanas_* · anomalias_detalle
            eventos_ciudad · diario_ciudad · dim_cuadricula · cluster_* · seleccion_k · cuadrante_enriquecido
reportes/   reporte_pulsored.html · kpis.json · tablero_pulsored.html
spark-events/   bitácoras de Spark (consumo de recursos por etapa)
```

### Capa de servicio (MariaDB 10.11)

| Tipo | Objetos |
|---|---|
| Tablas del pipeline | `cuadrante`, `perfil_semanal`, `ventana_ahorro`, `anomalia`, `evento_ciudad`, `diario_ciudad`, `cluster_perfil`, `cluster_resumen`, `seleccion_k`, `dq_resultado` (histórico), `dq_por_dia` |
| Tablas del negocio | `param_roi` (supuestos editables por Finanzas o Red), `cluster_etiqueta` (etiquetas validadas por analistas) |
| Vistas | `v_kpi_ejecutivo`, `v_mapa_cuadrantes`, `v_hotspots`, `v_ahorro_por_segmento`, `v_ahorro_estimado`, `v_cluster` |
| Usuarios | `pipeline_rw` (contraseña en Secret Manager) y `tablero_ro` (solo lectura, exige SSL) |

---

## Calidad de datos

| Control | Tipo | Regla |
|---|---|---|
| `llaves_duplicadas` | Crítico | 0 duplicados de (cuadrante, instante, país) en staging |
| `cuadrantes_sin_geometria` | Crítico | Todo cuadrante con actividad existe en la cuadrícula oficial |
| `valor_minimo_actividad` | Crítico | Ninguna actividad negativa |
| `tasa_cuarentena` | Crítico | Como máximo 1 % de filas inválidas en el crudo |
| `requisito_volumen_raw_gb` | Alerta | Al menos 15 GB procesados (requisito del proyecto) |
| `cobertura_temporal_min_dia` / `cobertura_espacial_min_dia` | Alerta | Al menos 97 % de intervalos y cuadrantes por día |
| `continuidad_calendario_dias` | Alerta | Sin días faltantes |
| `pct_fecha_distinta_archivo` | Alerta | Como máximo 1 % de registros fuera del día de su archivo |
| `centroides_fuera_de_milan` | Alerta | Georreferencia coherente |

---

## Parámetros de negocio

Todos viven en `jobs/common.py` (`PARAMS`) y se versionan con el código:

| Parámetro | Valor | Significado |
|---|---|---|
| `zona_horaria` | Europe/Rome | Los timestamps vienen en UTC; el análisis usa hora local |
| `tipico_inicio` / `tipico_fin` | 2013-11-04 / 2013-12-22 | Semanas completas sin temporada navideña (línea base) |
| `festivos` | 6 fechas | Todos los Santos, San Ambrosio, Inmaculada, Navidad, San Esteban, Año Nuevo |
| `percentil_hotspot` | 0.95 | El 5 % de mayor presión se marca como hotspot |
| `alfa_ahorro` | 0.15 | Una hora es elegible si su p95 es menor que el 15 % de la hora pico |
| `min_horas_ventana` | 2 | Duración mínima de una ventana de ahorro |
| `z_anomalia` | 4.0 | Umbral del z robusto |
| `umbral_completitud` | 0.97 | Cobertura mínima esperada por día |

---

## Cómo replicarlo (resumen)

Todo se ejecuta desde **Cloud Shell**. La guía completa, con capturas de lo esperado y solución
de problemas, está en [COMO_EMPEZAR.md](COMO_EMPEZAR.md).

```bash
export PROYECTO=tu-id-de-proyecto
bash infra/00_crear_infraestructura.sh            # ~5 min
bash infra/01_configurar_mariadb.sh               # esperar ~5 min tras el paso anterior
export DV_NOMBRE="Tu Nombre" DV_EMAIL="tu@correo.com" DV_INSTITUCION="Tu universidad"
bash ingest/lanzar_en_vm.sh iniciar               # descarga en la VM; avance: ... estado
bash infra/02_ejecutar_pipeline.sh                # perfil cuota12 por defecto
bash infra/03_prueba_escalabilidad.sh             # misma carga con 4 núcleos (opcional)
bash tablero/generar_tablero.sh                   # tablero interactivo
```

**Perfiles de clúster.** Los proyectos nuevos suelen tener una cuota global de 12 vCPU
(`CPUS_ALL_REGIONS`), y la VM de MariaDB ocupa 2 de ellas. Por eso el perfil predeterminado cabe en 12:

| `PERFIL` | Máquinas | Núcleos de trabajo | vCPU con la VM | Etiqueta |
|---|---|---|---|---|
| `cuota12` (predeterminado) | 1× n2-standard-2 + 2× n2-standard-4 | 8 | 12 | `8cores` |
| `cuota8` | 1× n2-standard-2 + 2× n2-standard-2 | 4 | 8 | `4cores` |
| `estandar` | 1× n2-standard-4 + 2× n2-standard-8 | 16 | 22 | `16cores` |

Se elige con `PERFIL=estandar bash infra/02_ejecutar_pipeline.sh`. Para escalamiento horizontal
se agrega `WORKERS=4`. El script revisa la cuota antes de crear el clúster.

**Corrida de referencia del proyecto:** perfil `cuota12` (etiqueta `8cores`), y como prueba de
escalabilidad vertical el perfil `cuota8` (etiqueta `4cores`).

---

## Pruebas

```bash
pip install -r requirements-dev.txt
python tools/generar_muestra_sintetica.py --salida /tmp/lake
PYTHONPATH=jobs pytest -q tests/
```

Las pruebas unitarias cubren cinco cosas:
- la regla de validez y la cuarentena;
- la desduplicación y consolidación de filas parciales;
- la conversión UTC → Milán y el calendario (festivos, día de la semana);
- el agrupamiento de ventanas de ahorro;
- la lectura robusta de la cuadrícula.

El pipeline completo también corre de principio a fin sobre la muestra sintética, que trae
defectos y un evento inyectados. La detección de anomalías recupera ese evento y la
segmentación recupera los perfiles sintéticos. **La muestra sintética solo valida el código;
sus números no son resultados.**

---

## Limitaciones conocidas de los datos

- **Unidades escaladas.** Los valores están escalados por anonimización: sirven para comparar zonas y horas, no son conteos absolutos. Por la misma razón no se suman SMS, voz y datos entre sí.
- **Un solo operador y un periodo corto.** Son datos de Telecom Italia de 2013, de 2 meses, e incluyen la temporada navideña, que se excluye de la línea base.
- **Cuadrícula, no celdas.** Las zonas son cuadrantes de unos 235 m, no celdas reales. La presión es un indicador de demanda, no una medición de la saturación del equipo.
- **Umbral en el registro de internet.** Una sesión de internet solo se registra si dura más de 15 minutos o supera 5 MB.
- **Datos sin registro.** Un NULL significa que no hubo actividad registrada, y se trata como 0; el supuesto está documentado en el job 01.

---

## Fuentes y licencias

- Telecom Italia (2015). *Telecommunications - SMS, Call, Internet - MI*. Harvard Dataverse. doi:10.7910/DVN/EGZHFV. Licencia ODbL.
- Telecom Italia (2015). *Milano Grid*. Harvard Dataverse. doi:10.7910/DVN/QJWLFU.
- Barlacchi, G. et al. (2015). A multi-source dataset of urban life in the city of Milan and the Province of Trentino. *Scientific Data, 2*, 150055. doi:10.1038/sdata.2015.55.
- GSMA. *Energy Efficiency: An Overview* (participación de la energía en el OPEX de red).

Los datos **no se incluyen** en el repositorio: se descargan de la fuente con `ingest/`.
Harvard Dataverse pide un registro de uso (*guestbook*) en cada descarga.

---

## Publicar este repositorio en GitHub

```bash
cd pulsored
git init -b main
git add .
git commit -m "PulsoRed: pipeline Big Data en GCP/Dataproc"
git remote add origin https://github.com/TU-USUARIO/pulsored.git
git push -u origin main
```

El archivo `.gitignore` ya excluye los artefactos locales: el driver JDBC descargado,
`resultados/`, certificados y cachés.
