#!/usr/bin/env bash
# PulsoRed | Paso 3: lanza la descarga de los 19.4 GB DENTRO de la VM (en segundo plano)
# y deja consultar su avance desde CLOUD SHELL. Puedes cerrar Cloud Shell mientras descarga.
# Harvard Dataverse pide un registro de uso (guestbook): define antes tus datos reales:
#   export DV_NOMBRE="Tu Nombre" DV_EMAIL="tu@correo.com" DV_INSTITUCION="Tu universidad"
# Uso (en Cloud Shell, raiz del repositorio):
#   bash ingest/lanzar_en_vm.sh iniciar
#   bash ingest/lanzar_en_vm.sh estado
set -euo pipefail
cd "$(dirname "$0")/.."
PROYECTO="${PROYECTO:?Primero: export PROYECTO=tu-id-de-proyecto}"
ZONA="us-central1-a"; LAKE="gs://${PROYECTO}-pulsored-lake"
ssh_vm() { gcloud compute ssh pulsored-mariadb --zone="$ZONA" --command="$1"; }

case "${1:-estado}" in
  iniciar)
    : "${DV_NOMBRE:?Define: export DV_NOMBRE=\"Tu Nombre\" DV_EMAIL=\"tu@correo.com\" DV_INSTITUCION=\"Tu universidad\"}"
    : "${DV_EMAIL:?Define: export DV_EMAIL=\"tu@correo.com\"}"
    vars=$(printf 'DV_NOMBRE=%q DV_EMAIL=%q DV_INSTITUCION=%q DV_CARGO=%q DATAVERSE_TOKEN=%q' \
           "$DV_NOMBRE" "$DV_EMAIL" "${DV_INSTITUCION:-}" "${DV_CARGO:-Estudiante}" "${DATAVERSE_TOKEN:-}")
    ssh_vm "mkdir -p ~/pulsored_setup"
    gcloud compute scp ingest/descargar_dataverse.sh pulsored-mariadb:~/pulsored_setup/ --zone="$ZONA"
    ssh_vm "cd ~/pulsored_setup; $vars nohup bash descargar_dataverse.sh api $LAKE > ~/ingesta.log 2>&1 < /dev/null &"
    echo "Ingesta iniciada en la VM. Consulta el avance con: bash ingest/lanzar_en_vm.sh estado" ;;
  estado)
    ssh_vm "tail -n 12 ~/ingesta.log 2>/dev/null; echo; \
            if pgrep -f '[d]escargar_dataverse.sh api' >/dev/null; then echo 'ESTADO: EN CURSO'; \
            else echo 'ESTADO: TERMINADO (revisa las lineas de arriba)'; fi"
    n=$(gcloud storage ls "$LAKE/raw/telecom/" 2>/dev/null | grep -c "sms-call-internet-mi" || true)
    echo "Archivos diarios en el bucket: $n de 62" ;;
  *) echo "uso: bash ingest/lanzar_en_vm.sh iniciar|estado"; exit 1 ;;
esac
