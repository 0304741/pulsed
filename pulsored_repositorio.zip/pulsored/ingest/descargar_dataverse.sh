#!/usr/bin/env bash
# PulsoRed | Ingesta RAW: Harvard Dataverse -> GCS con manifiesto de linaje (MD5).
# Se lanza desde Cloud Shell con ingest/lanzar_en_vm.sh (corre dentro de la VM).
#
# Dataverse >= 6.10 exige una respuesta de "guestbook" (registro de uso) para descargar:
# un GET simple devuelve 400. El script lo detecta y reintenta con POST + guestbookResponse,
# usando DV_NOMBRE, DV_EMAIL, DV_INSTITUCION, DV_CARGO (y DATAVERSE_TOKEN si se define).
#
# Modo api  : bash descargar_dataverse.sh api   gs://PROYECTO-pulsored-lake
# Modo local: bash descargar_dataverse.sh local gs://PROYECTO-pulsored-lake ~/carpeta
# Es idempotente: omite archivos que ya existen en GCS. Al final verifica 62 archivos y >= 15 GB.
set -euo pipefail
MODO="${1:?modo: api | local}"; LAGO="${2:?destino gs://...}"; CARPETA="${3:-}"
API="${DV_API:-https://dataverse.harvard.edu/api}"
DOI_TEL="doi:10.7910/DVN/EGZHFV"    # Telecommunications - SMS, Call, Internet - MI
DOI_GRID="doi:10.7910/DVN/QJWLFU"   # Milano Grid (GeoJSON, WGS 84 / EPSG:4326)
MAN="manifiesto_raw_$(date -u +%Y%m%dT%H%M%SZ).csv"
TMP=$(mktemp -d); trap 'rm -rf "$TMP"' EXIT
HDR=(); [[ -n "${DATAVERSE_TOKEN:-}" ]] && HDR=(-H "X-Dataverse-key: ${DATAVERSE_TOKEN}")
echo "archivo,destino,id_dataverse,md5_fuente,md5_copia,verificacion,bytes,cargado_utc" > "$MAN"

existe() { gcloud storage ls "$1" >/dev/null 2>&1; }

subir() {  # archivo_local destino_gcs id md5_fuente
  local f="$1" dest="$2" id="$3" md5f="$4" md5c bytes ver="sin_md5_fuente"
  md5c=$(md5sum "$f" | cut -d' ' -f1); bytes=$(stat -c%s "$f")
  if [[ "$md5f" != "n/d" ]]; then
    if [[ "$md5f" == "$md5c" ]]; then ver="ok"; else
      ver="MD5_DISTINTO"; echo "ADVERTENCIA: MD5 distinto en $(basename "$f") (fuente $md5f, copia $md5c)" >&2
    fi
  fi
  gcloud storage cp "$f" "$dest" --quiet
  echo "$(basename "$f"),$dest,$id,$md5f,$md5c,$ver,$bytes,$(date -u +%FT%TZ)" >> "$MAN"
}

listar() {  # DOI prefijo -> id<TAB>nombre<TAB>md5<TAB>es_tabular
  curl -sSf "${HDR[@]}" "$API/datasets/:persistentId/?persistentId=$1" | jq -r --arg p "$2" '
    .data.latestVersion.files[].dataFile
    | {id, n: (.originalFileName // .filename), m: (.md5 // .checksum.value // "n/d"),
       t: (if .originalFileName then "si" else "no" end)}
    | select(.n | startswith($p)) | [.id, .n, .m, .t] | @tsv'
}

guestbook_json() {
  jq -n --arg n "${DV_NOMBRE:-}" --arg e "${DV_EMAIL:-}" --arg i "${DV_INSTITUCION:-}" \
        --arg p "${DV_CARGO:-}" \
     '{guestbookResponse: ({name: $n, email: $e, institution: $i, position: $p}
                           | with_entries(select(.value != "")) + {answers: []})}'
}

bajar() {  # url destino -> 0 si descargo
  local url="$1" out="$2" code firmado
  code=$(curl -sS -L --retry 3 "${HDR[@]}" -o "$out" -w '%{http_code}' "$url" || true)
  [[ "$code" == "200" ]] && return 0
  if [[ "$code" == "400" ]]; then
    # Dataverse >= 6.10: se requiere guestbookResponse via POST (devuelve URL firmada)
    code=$(curl -sS -X POST "${HDR[@]}" -H "Content-Type: application/json" \
             -d "$(guestbook_json)" -o "$TMP/resp" -w '%{http_code}' "$url" || true)
    if [[ "$code" == "200" ]]; then
      if head -c1 "$TMP/resp" | grep -q '{'; then
        firmado=$(jq -r '.data.signedUrl // .data.url // .signedUrl //
                         ([.. | strings | select(test("^https?://"))][0]) // empty' "$TMP/resp")
        [[ -n "$firmado" ]] && curl -sSfL --retry 3 -o "$out" "$firmado" && return 0
      else
        mv "$TMP/resp" "$out"; return 0   # el POST devolvio el archivo directamente
      fi
    fi
    echo "Dataverse rechazo la descarga con guestbook (HTTP $code). Respuesta:" >&2
    head -c 1000 "$TMP/resp" >&2 2>/dev/null || true; echo >&2
  else
    echo "HTTP $code en $url. Respuesta:" >&2; head -c 600 "$out" >&2 2>/dev/null || true; echo >&2
  fi
  return 1
}

descargar() {  # DOI prefijo carpeta_destino nombre_fijo(opcional)
  listar "$1" "$2" | while IFS=$'\t' read -r id nombre md5 tabular; do
    local final="${4:-$nombre}" dest="$LAGO/raw/$3/${4:-$nombre}" url="$API/access/datafile/$id"
    [[ "$tabular" == "si" ]] && url="${url}?format=original"
    if existe "$dest"; then echo "ya existe, se omite: $final"; continue; fi
    echo "descargando $nombre (id $id)"
    bajar "$url" "$TMP/$final" || { echo "ERROR descargando $nombre" >&2; exit 1; }
    subir "$TMP/$final" "$dest" "$id" "$md5"; rm -f "$TMP/$final"; sleep 1
  done
}

case "$MODO" in
  api)
    descargar "$DOI_TEL" "sms-call-internet-mi" telecom
    descargar "$DOI_GRID" "milano-grid" grid "milano-grid.geojson" ;;
  local)
    [[ -d "$CARPETA" ]] || { echo "indicar la carpeta local con los archivos" >&2; exit 1; }
    for f in "$CARPETA"/sms-call-internet-mi-*.txt; do
      existe "$LAGO/raw/telecom/$(basename "$f")" || subir "$f" "$LAGO/raw/telecom/$(basename "$f")" "manual" "n/d"
    done
    g=$(ls "$CARPETA"/milano-grid*.geojson | head -1)
    existe "$LAGO/raw/grid/milano-grid.geojson" || subir "$g" "$LAGO/raw/grid/milano-grid.geojson" "manual" "n/d" ;;
  *) echo "modo no valido: $MODO" >&2; exit 1 ;;
esac
gcloud storage cp "$MAN" "$LAGO/raw/_manifiestos/$MAN" --quiet

# Verificacion del requisito de escala (el job 02 lo vuelve a medir y lo registra)
n=$(gcloud storage ls "$LAGO/raw/telecom/sms-call-internet-mi-*.txt" | wc -l)
b=$(gcloud storage du -s "$LAGO/raw/telecom" | awk '{print $1}')
gb=$(awk -v b="$b" 'BEGIN{printf "%.2f", b/1e9}')
echo "Archivos de actividad: $n (esperados 62) | Volumen: $gb GB (requisito >= 15 GB)"
awk -v g="$gb" 'BEGIN{exit !(g >= 15)}' || { echo "ADVERTENCIA: volumen menor a 15 GB" >&2; exit 2; }
[[ "$n" -eq 62 ]] || { echo "ADVERTENCIA: faltan archivos diarios" >&2; exit 2; }
