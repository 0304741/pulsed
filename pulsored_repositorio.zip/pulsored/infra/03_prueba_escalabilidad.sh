#!/usr/bin/env bash
# PulsoRed | Prueba de escalabilidad (seccion 4.k del documento).
# Repite la misma carga con OTRO tamano de cluster. Las metricas de cada corrida quedan en
# calidad/metricas_ejecucion y calidad/benchmark con su etiqueta (4cores, 8cores, 16cores...)
# y el reporte HTML las compara lado a lado.
#
#   bash infra/03_prueba_escalabilidad.sh                 -> perfil cuota8 (4 nucleos), cabe en 12 vCPU
#   PERFIL=estandar WORKERS=4 bash infra/03_prueba_escalabilidad.sh   -> horizontal (necesita ~40 vCPU)
set -euo pipefail
cd "$(dirname "$0")/.."
PERFIL="${PERFIL:-cuota8}" bash infra/02_ejecutar_pipeline.sh
