#!/usr/bin/env bash
# PulsoRed | Paso 2: configura MariaDB en la VM (red, SSL, esquema, vistas y contrasenas).
# Se lanza desde CLOUD SHELL (en la raiz del repositorio):  bash infra/01_configurar_mariadb.sh
# El script se copia solo a la VM junto con sql/ y se ejecuta alla con sudo.
# Se puede repetir sin problema.
set -euo pipefail
ZONA="us-central1-a"
if [[ "$(hostname)" != "pulsored-mariadb" ]]; then
  cd "$(dirname "$0")/.."
  echo "==> Copiando sql/ y este script a la VM (la primera vez gcloud crea tus llaves SSH: Enter, Enter)"
  gcloud compute ssh pulsored-mariadb --zone="$ZONA" --command="mkdir -p ~/pulsored_setup"
  gcloud compute scp --recurse sql infra/01_configurar_mariadb.sh pulsored-mariadb:~/pulsored_setup/ --zone="$ZONA"
  echo "==> Ejecutando la configuracion dentro de la VM"
  gcloud compute ssh pulsored-mariadb --zone="$ZONA" \
    --command="sudo bash ~/pulsored_setup/01_configurar_mariadb.sh"
  exit $?
fi
# ---- a partir de aqui corre DENTRO de la VM ----
cd "$(dirname "$0")"
command -v mariadb >/dev/null || { echo "MariaDB aun no esta instalada: espera 2-3 minutos y vuelve a ejecutar"; exit 1; }

# 1) Escuchar en la red y habilitar SSL con certificado autofirmado (requerido por tablero_ro)
mkdir -p /etc/mysql/ssl
if [[ ! -f /etc/mysql/ssl/server-cert.pem ]]; then
  openssl req -x509 -newkey rsa:2048 -nodes -days 825 -subj "/CN=pulsored-mariadb" \
    -keyout /etc/mysql/ssl/server-key.pem -out /etc/mysql/ssl/server-cert.pem
  chown mysql:mysql /etc/mysql/ssl/*.pem && chmod 600 /etc/mysql/ssl/server-key.pem
fi
cat > /etc/mysql/mariadb.conf.d/90-pulsored.cnf << 'CNF'
[mysqld]
bind-address = 0.0.0.0
ssl_cert = /etc/mysql/ssl/server-cert.pem
ssl_key  = /etc/mysql/ssl/server-key.pem
CNF
systemctl restart mariadb

# 2) Esquema y vistas
mariadb < sql/01_ddl_mariadb.sql
mariadb < sql/02_vistas_tablero.sql

# 3) Contrasenas: la del pipeline sale de Secret Manager; la del tablero se genera aqui
PW_PIPE=$(gcloud secrets versions access latest --secret=pulsored-mariadb-pipeline)
PW_RO=$(openssl rand -base64 18 | tr -d '/+=')
mariadb -e "ALTER USER 'pipeline_rw'@'%' IDENTIFIED BY '${PW_PIPE}';
            ALTER USER 'tablero_ro'@'%' IDENTIFIED BY '${PW_RO}' REQUIRE SSL;"

# 4) Supuestos del modelo de ROI (editables por Finanzas/Red; son SUPUESTOS, no mediciones)
mariadb pulsored -e "INSERT INTO param_roi VALUES
  ('n_sitios', 1000, 'sitios', 'SUPUESTO: area piloto'),
  ('kw_capa_apagable', 1.0, 'kW', 'SUPUESTO: capa de capacidad apagable por sitio'),
  ('tarifa_kwh', 2.5, 'MXN/kWh', 'SUPUESTO: tarifa media'),
  ('factor_realizacion', 0.6, 'fraccion', 'SUPUESTO: horas elegibles realmente ejecutadas'),
  ('costo_anual_plataforma', 200000, 'MXN', 'SUPUESTO: infraestructura + operacion')
  ON DUPLICATE KEY UPDATE valor = valor;"

echo
echo "============================================================"
echo " MariaDB lista. GUARDA estos datos para el tablero (Data Studio):"
echo "   usuario    : tablero_ro"
echo "   contrasena : ${PW_RO}"
echo "   certificado: /etc/mysql/ssl/server-cert.pem (en la VM)"
echo " Si pierdes la contrasena, vuelve a ejecutar este script (genera una nueva)."
echo "============================================================"
