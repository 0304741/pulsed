#!/usr/bin/env bash
# PulsoRed | Paso 4: arma el workflow segun el perfil de cluster, lo ejecuta y trae el reporte.
# Se ejecuta en CLOUD SHELL (raiz del repositorio). El workflow corre en GCP: si Cloud Shell
# se desconecta, el pipeline sigue; luego descarga el reporte con el comando del final.
#
# Perfiles (vCPU del cluster; la VM de MariaDB suma 2 vCPU mas a la cuota del proyecto):
#   cuota12  (predeterminado) 1x n2-standard-2 + 2x n2-standard-4 = 10 vCPU, 8 nucleos de trabajo
#   cuota8                    1x n2-standard-2 + 2x n2-standard-2 =  6 vCPU, 4 nucleos de trabajo
#   estandar                  1x n2-standard-4 + 2x n2-standard-8 = 20 vCPU, 16 nucleos de trabajo
# Uso:  bash infra/02_ejecutar_pipeline.sh              (perfil cuota12)
#       PERFIL=estandar bash infra/02_ejecutar_pipeline.sh
#       PERFIL=estandar WORKERS=4 bash infra/02_ejecutar_pipeline.sh   (escalamiento horizontal)
set -euo pipefail
cd "$(dirname "$0")/.."
PROYECTO="${PROYECTO:?Primero: export PROYECTO=tu-id-de-proyecto}"
REGION="us-central1"; ZONA="us-central1-a"
PERFIL="${PERFIL:-cuota12}"; WORKERS="${WORKERS:-2}"
LAKE="gs://${PROYECTO}-pulsored-lake"; CODE="gs://${PROYECTO}-pulsored-code"

case "$PERFIL" in
  cuota12)  MM=n2-standard-2; MW=n2-standard-4 ;;
  cuota8)   MM=n2-standard-2; MW=n2-standard-2 ;;
  estandar) MM=n2-standard-4; MW=n2-standard-8 ;;
  *) echo "PERFIL no valido: $PERFIL (usa cuota12, cuota8 o estandar)"; exit 1 ;;
esac
nucleos_trabajo=$(( WORKERS * ${MW##*-} ))
vcpu_total=$(( ${MM##*-} + nucleos_trabajo + 2 ))       # + 2 de la VM pulsored-mariadb
ETIQUETA="${nucleos_trabajo}cores"
ID="pulsored-${ETIQUETA}"
echo "Perfil $PERFIL: master $MM + ${WORKERS}x $MW | etiqueta de la corrida: $ETIQUETA | vCPU con la VM: $vcpu_total"

# Cuota global del proyecto (el limite que suele frenar a los proyectos nuevos)
glob=$(gcloud compute project-info describe --flatten=quotas \
        --format="csv[no-heading](quotas.metric,quotas.limit)" 2>/dev/null \
      | awk -F, '$1=="CPUS_ALL_REGIONS"{print int($2)}' || true)
if [[ -n "$glob" && "$glob" -lt "$vcpu_total" ]]; then
  echo "La cuota CPUS_ALL_REGIONS es $glob y este perfil necesita $vcpu_total. Usa PERFIL=cuota12 o cuota8."; exit 1
fi

n=$(gcloud storage ls "$LAKE/raw/telecom/" 2>/dev/null | grep -c "sms-call-internet-mi" || true)
[[ "$n" -gt 0 ]] || { echo "No hay datos en $LAKE/raw/telecom: termina primero la ingesta (paso 3)"; exit 1; }
[[ "$n" -eq 62 ]] || echo "ADVERTENCIA: hay $n de 62 archivos; el pipeline correra con lo disponible"

# El ultimo paso (carga a MariaDB) necesita la VM encendida
vm=$(gcloud compute instances describe pulsored-mariadb --zone="$ZONA" --format="value(status)" 2>/dev/null || true)
if [[ "$vm" != "RUNNING" ]]; then
  echo "Encendiendo la VM pulsored-mariadb (estaba: ${vm:-desconocido})..."
  gcloud compute instances start pulsored-mariadb --zone="$ZONA"
fi

gcloud storage cp jobs/*.py "$CODE/jobs/" --quiet   # siempre la version actual del codigo
sed -e "s/__PROYECTO__/${PROYECTO}/g" -e "s/__MAQUINA_MASTER__/${MM}/" -e "s/__MAQUINA_WORKER__/${MW}/" \
    -e "s/__WORKERS__/${WORKERS}/" -e "s/__ETIQUETA__/${ETIQUETA}/g" \
    infra/workflow_pulsored.yaml > "/tmp/${ID}.yaml"
gcloud dataproc workflow-templates import "$ID" --region="$REGION" --source="/tmp/${ID}.yaml" --quiet

echo "Avance en la consola: https://console.cloud.google.com/dataproc/workflows/instances?project=${PROYECTO}"
inicio=$(date +%s)
gcloud dataproc workflow-templates instantiate "$ID" --region="$REGION"
echo "Duracion total del workflow $ETIQUETA (incluye crear y borrar el cluster): $(( $(date +%s) - inicio )) s"

mkdir -p resultados
gcloud storage cp "$LAKE/reportes/reporte_pulsored.html" "$LAKE/reportes/kpis.json" resultados/ --quiet
echo "Reporte descargado en resultados/. Para bajarlo a tu computadora:"
echo "  cloudshell download resultados/reporte_pulsored.html"
