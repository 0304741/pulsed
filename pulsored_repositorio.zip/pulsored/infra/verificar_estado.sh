#!/usr/bin/env bash
# PulsoRed | "¿Voy bien?": revisa que exista cada pieza. Se ejecuta en CLOUD SHELL.
# No crea ni modifica nada; se puede correr en cualquier momento.
set -uo pipefail
PROYECTO="${PROYECTO:?Primero: export PROYECTO=tu-id-de-proyecto}"
ZONA="us-central1-a"; LAKE="gs://${PROYECTO}-pulsored-lake"; CODE="gs://${PROYECTO}-pulsored-code"
ok() { echo "  [OK]    $*"; }
falta() { echo "  [FALTA] $*"; }
chk() { local d="$1"; shift; if "$@" >/dev/null 2>&1; then ok "$d"; else falta "$d"; fi; }

echo "Proyecto: $PROYECTO"
echo "-- Paso 1 (infra/00)"
chk "Bucket del lago  $LAKE" gcloud storage buckets describe "$LAKE"
chk "Bucket de codigo $CODE" gcloud storage buckets describe "$CODE"
chk "Codigo del pipeline en el bucket" gcloud storage ls "$CODE/jobs/01_raw_a_staging.py"
chk "Driver JDBC en el bucket" gcloud storage ls "$CODE/jars/mariadb-java-client.jar"
chk "Cuenta de servicio pulsored-dataproc" gcloud iam service-accounts describe "pulsored-dataproc@${PROYECTO}.iam.gserviceaccount.com"
chk "Secreto pulsored-mariadb-pipeline" gcloud secrets describe pulsored-mariadb-pipeline
vm=$(gcloud compute instances describe pulsored-mariadb --zone="$ZONA" --format="value(status)" 2>/dev/null)
[[ "$vm" == "RUNNING" ]] && ok "VM pulsored-mariadb encendida" || falta "VM pulsored-mariadb (estado: ${vm:-no existe})"

echo "-- Paso 3 (ingesta)"
n=$(gcloud storage ls "$LAKE/raw/telecom/" 2>/dev/null | grep -c "sms-call-internet-mi" || true)
[[ "$n" -eq 62 ]] && ok "Archivos diarios: 62 de 62" || falta "Archivos diarios: $n de 62"
chk "Cuadricula milano-grid.geojson" gcloud storage ls "$LAKE/raw/grid/milano-grid.geojson"
if [[ "$n" -gt 0 ]]; then
  b=$(gcloud storage du -s "$LAKE/raw/telecom" | awk '{print $1}')
  echo "          volumen: $(awk -v b="$b" 'BEGIN{printf "%.2f", b/1e9}') GB (requisito >= 15 GB)"
fi

echo "-- Paso 4 (pipeline)"
chk "Staging (job 01)" gcloud storage ls "$LAKE/staging/actividad_celda/"
chk "Quality gate (job 02)" gcloud storage ls "$LAKE/calidad/dq_resultados/"
chk "Marts (job 03-04)" gcloud storage ls "$LAKE/marts/cuadrante_enriquecido/"
chk "Benchmark (job 05)" gcloud storage ls "$LAKE/calidad/benchmark/"
chk "Reporte HTML (job 06)" gcloud storage ls "$LAKE/reportes/reporte_pulsored.html"
