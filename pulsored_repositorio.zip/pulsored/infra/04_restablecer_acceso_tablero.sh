#!/usr/bin/env bash
# PulsoRed | Diagnostica y restablece el acceso del usuario de solo lectura (tablero_ro).
# "Access denied" tiene dos causas con el mismo mensaje: contrasena distinta o SSL inactivo
# (tablero_ro exige SSL). Este script genera una contrasena nueva, muestra si SSL esta activo
# y prueba el acceso real. Se ejecuta en CLOUD SHELL.
set -euo pipefail
ZONA="us-central1-a"
PW=$(openssl rand -base64 18 | tr -d '/+=')
gcloud compute ssh pulsored-mariadb --zone="$ZONA" --command="sudo mariadb -e \"ALTER USER 'tablero_ro'@'%' IDENTIFIED BY '$PW'; SHOW VARIABLES LIKE 'have_ssl';\" && mariadb -h 127.0.0.1 -u tablero_ro -p'$PW' --ssl pulsored -e 'SELECT COUNT(*) AS cuadrantes FROM v_mapa_cuadrantes; SHOW STATUS LIKE \"Ssl_version\";'" \
  || { echo "Fallo la prueba. Si arriba dice have_ssl DISABLED, ejecuta: bash infra/01_configurar_mariadb.sh"; exit 1; }
echo
echo "Acceso verificado. Nueva contrasena de tablero_ro: $PW"
