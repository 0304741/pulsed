#!/usr/bin/env bash
# PulsoRed | Paso 1: infraestructura minima ("Tsuru"). Se ejecuta en CLOUD SHELL.
# Crea: APIs, red, 2 buckets, 1 cuenta de servicio, 1 secreto, 1 VM con MariaDB y firewalls.
# El cluster Dataproc NO se crea aqui: es efimero y lo crea/destruye el workflow (paso 02).
# Es IDEMPOTENTE: si algo falla, corrige y vuelve a ejecutarlo; lo que ya existe se omite.
# Uso:  export PROYECTO=tu-id-de-proyecto && bash infra/00_crear_infraestructura.sh
set -euo pipefail
cd "$(dirname "$0")/.."
PROYECTO="${PROYECTO:?Primero: export PROYECTO=tu-id-de-proyecto}"
# IPs publicadas por Google para el conector MySQL de Data Studio (antes Looker Studio)
RANGOS_LOOKER="${RANGOS_LOOKER:-142.251.74.0/23}"
REGION="us-central1"; ZONA="us-central1-a"
LAKE="gs://${PROYECTO}-pulsored-lake"; CODE="gs://${PROYECTO}-pulsored-code"
SA="pulsored-dataproc@${PROYECTO}.iam.gserviceaccount.com"
JDBC_VERSION="3.4.1"
paso() { echo; echo "==> $*"; }
omitir() { echo "    (ya existe, se omite)"; }

gcloud config set project "$PROYECTO" >/dev/null

paso "1/9 Habilitando APIs (1-2 minutos la primera vez)"
gcloud services enable dataproc.googleapis.com compute.googleapis.com \
  storage.googleapis.com secretmanager.googleapis.com iam.googleapis.com

paso "2/9 Red 'default' y Private Google Access"
if gcloud compute networks describe default >/dev/null 2>&1; then omitir; else
  gcloud compute networks create default --subnet-mode=auto
  gcloud compute firewall-rules create default-allow-internal --network=default \
    --allow=tcp,udp,icmp --source-ranges=10.128.0.0/9
fi
# Dataproc sin IP publica necesita Private Google Access para llegar a Cloud Storage
gcloud compute networks subnets update default --region="$REGION" --enable-private-ip-google-access

paso "3/9 Revisando cuota de CPUs (el cluster usa 20 vCPU N2 y la VM 2 vCPU E2)"
cuota() { "$@" --flatten=quotas --format="csv[no-heading](quotas.metric,quotas.limit)" 2>/dev/null || true; }
reg=$(cuota gcloud compute regions describe "$REGION"); proj=$(cuota gcloud compute project-info describe)
cpus=$(echo "$reg" | awk -F, '$1=="CPUS"{print int($2)}')
n2=$(echo "$reg" | awk -F, '$1=="N2_CPUS"{print int($2)}')
glob=$(echo "$proj" | awk -F, '$1=="CPUS_ALL_REGIONS"{print int($2)}')
echo "    CPUS en $REGION: ${cpus:-?} | N2_CPUS: ${n2:-?} | CPUS_ALL_REGIONS: ${glob:-?}"
if awk -v a="${cpus:-0}" -v b="${n2:-0}" -v c="${glob:-0}" 'BEGIN{exit !(a<22 || b<20 || c<22)}'; then
  echo "    ADVERTENCIA: la cuota no alcanza para el cluster estandar. Ver 'Cuota de CPUs' en COMO_EMPEZAR.md."
  echo "    La infraestructura se crea igual; ajusta el tamano del cluster antes del paso 02."
fi

paso "4/9 Buckets del lago y del codigo"
for b in "$LAKE" "$CODE"; do
  if gcloud storage buckets describe "$b" >/dev/null 2>&1; then echo "    $b"; omitir; else
    gcloud storage buckets create "$b" --location="$REGION" --uniform-bucket-level-access
  fi
done
# Spark exige que exista el directorio de event logs (evidencia de recursos, seccion 4.k)
echo "" | gcloud storage cp - "$LAKE/spark-events/.keep" --quiet

paso "5/9 Cuenta de servicio y permisos (minimo privilegio)"
if gcloud iam service-accounts describe "$SA" >/dev/null 2>&1; then omitir; else
  gcloud iam service-accounts create pulsored-dataproc --display-name="PulsoRed Dataproc"
  echo "    esperando a que la cuenta se propague..."; sleep 20
fi
for rol in roles/dataproc.worker roles/secretmanager.secretAccessor; do
  gcloud projects add-iam-policy-binding "$PROYECTO" --member="serviceAccount:$SA" \
    --role="$rol" --condition=None --quiet >/dev/null
done
for b in "$LAKE" "$CODE"; do
  gcloud storage buckets add-iam-policy-binding "$b" --member="serviceAccount:$SA" \
    --role=roles/storage.objectAdmin >/dev/null
done
echo "    permisos asignados"

paso "6/9 Secreto con la contrasena del usuario del pipeline"
if gcloud secrets describe pulsored-mariadb-pipeline >/dev/null 2>&1; then omitir; else
  openssl rand -base64 24 | tr -d '/+=\n' | gcloud secrets create pulsored-mariadb-pipeline --data-file=-
fi

paso "7/9 VM pulsored-mariadb (base de datos + maquina de descarga)"
if gcloud compute instances describe pulsored-mariadb --zone="$ZONA" >/dev/null 2>&1; then omitir; else
  gcloud compute instances create pulsored-mariadb --zone="$ZONA" \
    --machine-type=e2-medium --image-family=debian-12 --image-project=debian-cloud \
    --boot-disk-size=50GB --service-account="$SA" --scopes=cloud-platform --tags=pulsored-db \
    --metadata=startup-script='apt-get update && apt-get install -y mariadb-server jq curl'
fi

paso "8/9 Reglas de firewall (solo aplican a la VM, etiqueta pulsored-db)"
regla() {  # nombre puerto rangos
  if gcloud compute firewall-rules describe "$1" >/dev/null 2>&1; then echo "    $1"; omitir; else
    gcloud compute firewall-rules create "$1" --network=default --allow="$2" \
      --source-ranges="$3" --target-tags=pulsored-db
  fi
}
regla pulsored-ssh tcp:22 0.0.0.0/0                        # gcloud compute ssh (llaves SSH)
regla pulsored-mariadb-interno tcp:3306 10.128.0.0/20      # Dataproc -> MariaDB
regla pulsored-mariadb-datastudio tcp:3306 "$RANGOS_LOOKER" # tablero -> MariaDB

paso "9/9 Driver JDBC de MariaDB y codigo del pipeline"
mkdir -p jars
curl -sSfL "https://repo1.maven.org/maven2/org/mariadb/jdbc/mariadb-java-client/${JDBC_VERSION}/mariadb-java-client-${JDBC_VERSION}.jar" \
  -o jars/mariadb-java-client.jar
gcloud storage cp jars/mariadb-java-client.jar "$CODE/jars/" --quiet
gcloud storage cp jobs/*.py "$CODE/jobs/" --quiet

IP=$(gcloud compute instances describe pulsored-mariadb --zone="$ZONA" \
     --format="get(networkInterfaces[0].accessConfigs[0].natIP)")
cat << FIN

============================================================
 Infraestructura lista
   Lago de datos : $LAKE
   Codigo        : $CODE
   VM MariaDB    : pulsored-mariadb ($ZONA), IP externa $IP
 Siguiente paso (esperar ~5 min a que la VM instale MariaDB):
   bash infra/01_configurar_mariadb.sh
============================================================
FIN
