# Explicación del código

Este documento recorre el repositorio en el orden en que se ejecuta. Para cada pieza explica
qué hace, por qué se hizo así y cuál es la técnica de Spark o de SQL que la sostiene.
Los fragmentos de código son extractos reales del repositorio.

---

## 1. Ingesta: `ingest/`

### `descargar_dataverse.sh`

Corre **dentro de la VM** `pulsored-mariadb`. Hay dos razones: la descarga (19.4 GB) no debe
depender del navegador, y Cloud Shell solo tiene 5 GB de disco. La lanza `lanzar_en_vm.sh`
desde Cloud Shell, que después permite consultar su avance.

Para cada archivo del dataset hace lo siguiente:

1. **Lista** los archivos con la API de Dataverse (`/api/datasets/:persistentId`) y lee su ID, nombre y MD5.
2. **Descarga** el archivo. Desde Dataverse 6.10, un `GET` simple devuelve **400** si el dataset tiene registro de uso (*guestbook*). El script lo detecta y reintenta con `POST` y un cuerpo `guestbookResponse` (nombre, correo, institución). Dataverse responde con una **URL firmada**, y de ahí se baja el archivo.
3. **Verifica el MD5** contra el que publica la fuente.
4. **Sube** el archivo a `raw/` y anota una fila en el **manifiesto de linaje** (`raw/_manifiestos/*.csv`) con el ID de origen, el MD5 de la fuente, el MD5 de la copia, el tamaño y la fecha.

Es **idempotente**: si un archivo ya está en el bucket, lo omite. Al final verifica los dos
requisitos de escala: 62 archivos y al menos 15 GB.

```bash
code=$(curl -sS -L --retry 3 "${HDR[@]}" -o "$out" -w '%{http_code}' "$url" || true)
[[ "$code" == "200" ]] && return 0
if [[ "$code" == "400" ]]; then
  # Dataverse >= 6.10: se requiere guestbookResponse via POST (devuelve URL firmada)
  code=$(curl -sS -X POST ... -d "$(guestbook_json)" -o "$TMP/resp" -w '%{http_code}' "$url")
```

---

## 2. Módulo común: `jobs/common.py`

Todos los jobs lo importan (Dataproc lo distribuye con `pythonFileUris`).

- **`ESQUEMA_RAW`**: esquema explícito del TSV. Evita `inferSchema`, que obligaría a leer los 19.4 GB una vez más, y fija los tipos desde el origen. Incluye la columna `_corrupt_record`, donde Spark deja las filas mal formadas en lugar de descartarlas en silencio.
- **`PARAMS`**: parámetros de negocio (zona horaria, festivos, periodo típico y umbrales). Están versionados junto al código, así cada resultado queda asociado a los parámetros que lo produjeron.
- **`spark_session()`**: activa Adaptive Query Execution (AQE), que ajusta las particiones del shuffle en tiempo de ejecución. También activa la sobreescritura dinámica de particiones y fija la sesión en UTC.
- **`Cronometro`**: al terminar cada job anexa a `calidad/metricas_ejecucion` una fila con segundos, ejecutores activos, versión de Spark, conteos y la **etiqueta de la corrida** (`8cores`, `4cores`…). Esta bitácora es la base de la sección de rendimiento y escalabilidad.
- **`div(a, b)`**: división segura (`NULL` si el denominador es 0). Es compatible con el modo ANSI de Spark 4.
- **`bytes_en`, `borrar`, `escribir_texto`**: operaciones de archivos con la API de Hadoop. Funcionan igual en `gs://` y en local, sin dependencias extra.

---

## 3. Job 01: `01_raw_a_staging.py`

Tiene tres pasadas y un paso final, diseñados para leer el crudo el menor número de veces.

**Pasada A: perfil de calidad del crudo.** Es una sola agregación agrupada por archivo, que
cuenta filas, inválidas, corruptas, nulos por columna y negativos. No materializa los datos.

**Pasada B: cuarentena.** Solo se ejecuta si la pasada A encontró filas inválidas. Esas filas
se guardan aparte, con su motivo trazable, en lugar de perderse.

```python
def regla_valida():
    """True solo si la fila es utilizable; los NULL se tratan como invalidos."""
    ok = (F.col("_corrupt_record").isNull()
          & F.col("square_id").between(1, PARAMS["n_cuadrantes"])
          & F.col("time_interval").isNotNull())
    for c in ACTIVIDADES:
        ok = ok & (F.col(c).isNull() | (F.col(c) >= 0))
    return F.coalesce(ok, F.lit(False))
```

**Pasada C: limpieza.** La desduplicación se hace en **dos pasos**, porque el dataset puede
repartir la actividad de una misma llave en varias filas (una con SMS y voz, otra con internet):

```python
validos = validos.dropDuplicates(CLAVE + ACTIVIDADES)          # 1) duplicados exactos
consolidado = (validos.groupBy(CLAVE).agg(                     # 2) filas parciales
    *[F.sum(F.coalesce(F.col(c), F.lit(0.0))).alias(c) for c in ACTIVIDADES], ...))
```

Si se hiciera solo el paso 1, las filas parciales quedarían duplicadas. Si se hiciera solo el
paso 2, los duplicados exactos se sumarían dos veces.

Los timestamps vienen en milisegundos UTC y se convierten a **hora de Milán**
(`from_utc_timestamp`). Sin esa conversión, la "hora pico" quedaría corrida una hora y los
días se partirían mal. El resultado se escribe en **Parquet + Snappy particionado por `dt`**
(fecha local): 62 particiones de tamaño razonable, sin el problema de muchos archivos pequeños.

**Paso D: consolidación cuadrante-intervalo.** Parte del Parquet recién escrito, no del crudo:
la lectura es columnar y el volumen es varias veces menor. Suma los países y deriva `hora`, `slot`, día de
la semana (1 = lunes) y festivo. Voz, SMS e internet se mantienen **separados**: vienen
escalados por anonimización y sumarlos no tendría sentido.

---

## 4. Job 02: `02_calidad.py` (quality gate)

**Catálogo de la cuadrícula.** Lee el GeoJSON oficial y calcula el centroide de cada cuadrante
con **funciones de orden superior** de Spark SQL, sin UDFs de Python (que serían lentas). El
nombre de la propiedad del identificador se detecta solo, porque la fuente podría variar:

```python
.withColumn("lon", F.expr("aggregate(slice(anillo, 1, n), 0D, (a, p) -> a + p[0]) / n"))
```

**Controles.** Son 10: 4 críticos y 6 de alerta; la tabla completa está en el README. Cada
control produce una fila (`control, valor, umbral, estado, severidad`). Si algún control
**crítico** falla, el job termina con `sys.exit(1)` y Dataproc detiene el workflow: **nunca se
publican datos que no pasaron la validación**. Las alertas se reportan sin detener, por ejemplo
el requisito de al menos 15 GB o la cobertura por día.

---

## 5. Job 03: `03_marts.py`

**Serie horaria densificada.** Si un cuadrante no tuvo registros en una hora, esa hora no
existe en el dato. Para que medias y percentiles sean correctos, se construye un **esqueleto**
(cuadrantes × horas) y se rellena con 0. Solo se densifican las horas que existen a nivel
ciudad, para no confundir un hueco de la fuente con "cero tráfico":

```python
esqueleto = cuadrantes.crossJoin(F.broadcast(horas_ciudad))
return esqueleto.join(h, ["square_id", "dt", "hora"], "left").na.fill(0.0, [...])
```

El calendario (unas 1,500 filas) viaja en **broadcast** a cada ejecutor, así que el cruce no
genera shuffle. El resultado se escribe y se vuelve a leer para **cortar el linaje**, y los
cálculos siguientes parten de Parquet.

**Perfil semanal típico.** Para cada cuadrante, día de la semana y hora calcula la media y el
p95 (`percentile_approx`). Usa solo el periodo típico, sin Navidad ni festivos.

**Presión de capacidad.** Primero identifica la hora pico de día laboral de cada cuadrante
(`row_number` sobre una ventana). Luego aplica un `percent_rank` global sobre el tráfico de
esa hora: el índice de presión es el percentil del cuadrante dentro de la ciudad, y el 5 %
superior se marca como hotspot. Una ventana global sin partición es aceptable aquí porque
solo son unas 10,000 filas.

**Ventanas de ahorro (*gaps & islands*).** Una hora es elegible si **incluso su p95** de datos
y de voz queda por debajo del 15 % de la hora pico: es un criterio conservador que protege la
calidad de servicio. Las horas elegibles consecutivas forman una ventana; el truco clásico es
que `hora − número_de_fila` es constante dentro de cada racha:

```python
w = Window.partitionBy("square_id").orderBy("how")
islas = (p.filter("elegible")
          .withColumn("grupo", F.col("how") - F.row_number().over(w))
          .groupBy("square_id", "grupo")
          .agg(F.min("how").alias("inicio_how"), F.count(F.lit(1)).alias("duracion_h"))
          .filter(F.col("duracion_h") >= minh))
```

**Anomalías con z robusto.** Para cada cuadrante, día de la semana y hora se calculan la
**mediana** y el **MAD** del periodo típico, que un evento no distorsiona como sí distorsionaría
la media y la desviación estándar. Luego:

z = (x − mediana) / (1.4826 · MAD)

El factor 1.4826 hace que el MAD sea comparable con la desviación estándar en datos normales.
Se agrega un piso de escala del 5 % de la mediana para evitar z infinitos cuando el MAD vale
casi cero. Un punto se marca como anómalo si z ≥ 4 y el exceso es de al menos 50 %. Después
se agrupa por día y hora para obtener **eventos de ciudad** (varios cuadrantes a la vez).

---

## 6. Job 04: `04_segmentacion.py`

Cada cuadrante se describe con **48 números**: el tráfico medio por hora en día laboral (24) y
en fin de semana (24). Se dividen entre la media del propio cuadrante:

```python
ancha = x.groupBy("square_id").pivot("clave", CLAVES).agg(F.first("v")).na.fill(0.0)
media = sum(F.col(c) for c in CLAVES) / len(CLAVES)
for c in CLAVES:
    ancha = ancha.withColumn(c, div(F.col(c), F.col("media")))
```

Con esta normalización K-Means agrupa por **cuándo** se usa la red (la forma del perfil) y no
por **cuánto** (el volumen). Si no, solo separaría zonas grandes de zonas chicas. El `pivot`
recibe la lista de columnas explícita, lo que evita una pasada extra para descubrirlas.

El valor de k se elige entre 3 y 8 por **silhouette** (`ClusteringEvaluator`), y toda la curva
se guarda en `seleccion_k`. Las etiquetas (*Oficinas*, *Residencial*, *Ocio nocturno*…) se
**sugieren** con reglas simples sobre los centroides: cociente fin de semana / laboral y
proporción nocturna. Los analistas pueden fijar la etiqueta definitiva en la tabla
`cluster_etiqueta`, y las vistas priorizan esa etiqueta sobre la sugerida.

---

## 7. Job 05: `05_benchmark.py`

Es la evidencia de la **optimización de almacenamiento**. Ejecuta el mismo cálculo sobre el
TSV crudo y sobre el Parquet de staging:

- **B1, agregación completa** (tráfico por día): mide el beneficio de la lectura columnar y de la compresión.
- **B2, consulta selectiva** (un cuadrante en un día): mide la **poda de particiones** (`dt`) y el *predicate pushdown*. En Parquet solo se lee una partición; en TSV hay que leer los 19.4 GB.

También mide el tamaño de cada zona del lago y el factor de compresión (TSV / Parquet).
Todo se anexa con la etiqueta de la corrida, para comparar entre tamaños de clúster.

---

## 8. Job 06: `06_reporte_visual.py`

Genera `reportes/reporte_pulsored.html`, un reporte ejecutivo autocontenido con las gráficas
embebidas en base64. Incluye los KPIs, los mapas de presión y de ahorro, la semana típica, los
segmentos, los eventos, el modelo de ROI con su tabla de sensibilidad, la calidad y
**rendimiento y escalabilidad**. Esta última parte muestra el tiempo por job de cada corrida
(`8cores` contra `4cores`), el benchmark y el tamaño por zona. Si el clúster no tuviera
matplotlib, el reporte se genera igual, solo con tablas.

---

## 9. Job 07: `07_carga_mariadb.py`

- **Recarga idempotente.** Usa `mode("overwrite")` con `truncate=true`: vacía la tabla pero **conserva el DDL** (llaves primarias e índices). Un `overwrite` normal la borraría y la recrearía con tipos genéricos.
- **Histórico de calidad.** `dq_resultado` se carga con `append`, así queda la trazabilidad de todas las corridas.
- **Dialecto SQL.** La URL usa `jdbc:mysql://…?permitMysqlScheme=true` con el driver de MariaDB. Así Spark aplica su dialecto MySQL, que pone las comillas invertidas en los identificadores.
- **Credenciales.** La contraseña se lee de **Secret Manager** con la cuenta de servicio del clúster; nunca está en el código.

---

## 10. SQL: `sql/`

- **`01_ddl_mariadb.sql`.** Las tablas tienen llaves primarias compuestas que reflejan el grano de cada mart, por ejemplo `(square_id, dow, hora)`. Las **llaves foráneas no se declaran a propósito**: impedirían el `TRUNCATE` de la recarga. La integridad referencial se valida en el quality gate, antes de cargar, y con la consulta Q0 después de cargar. Hay dos usuarios con mínimo privilegio: `pipeline_rw` y `tablero_ro`, este último de solo lectura y con SSL obligatorio.
- **`02_vistas_tablero.sql`.** Seis vistas de negocio. `v_ahorro_estimado` combina las horas elegibles **medidas** con los supuestos de `param_roi` (sitios, kW, tarifa, realización y costo), que Finanzas puede editar sin tocar el pipeline.
- **`03_kpis_documento.sql`.** Once consultas (Q0–Q10). Cada cifra del documento técnico sale de una de ellas.

---

## 11. Orquestación e infraestructura: `infra/`

- **`00_crear_infraestructura.sh`** es idempotente: cada recurso se revisa antes de crearlo. También revisa la cuota de CPUs y avisa si no alcanza. Crea:
  - la red con Private Google Access (Dataproc sin IP pública llega a Cloud Storage);
  - la cuenta de servicio con permisos mínimos (`dataproc.worker`, acceso de objetos a sus buckets, lectura del secreto);
  - firewalls restringidos por etiqueta a la VM (SSH, Dataproc → 3306, Data Studio → 3306).
- **`workflow_pulsored.yaml`** es una **plantilla** con marcadores (`__PROYECTO__`, `__MAQUINA_MASTER__`, `__MAQUINA_WORKER__`, `__WORKERS__`, `__ETIQUETA__`). Declara los 7 pasos encadenados (`prerequisiteStepIds`) y el clúster efímero (`managedCluster`), con event logs de Spark en el lago y Component Gateway para ver la interfaz de Spark mientras corre.
- **`02_ejecutar_pipeline.sh`** llena la plantilla según el **perfil** (`cuota12`, `cuota8`, `estandar`, y `WORKERS` opcional). La etiqueta de la corrida es el número de núcleos de trabajo. Antes de crear el clúster verifica la cuota global `CPUS_ALL_REGIONS`, que es el límite que suele frenar a los proyectos nuevos.
- **`03_prueba_escalabilidad.sh`** repite la carga con otro perfil. Las dos corridas quedan comparadas en el reporte.

---

## 12. Tablero: `tablero/`

`generar_tablero.py` corre **dentro de la VM** y lee la capa de servicio con el cliente
`mariadb`, usando solo la biblioteca estándar de Python, sin instalar nada. Toma los KPIs, los
cuadrantes, la tendencia, los perfiles, las ventanas, los eventos, la calidad y los supuestos
de ROI, e incrusta los datos como JSON en `plantilla_tablero.html`.

El resultado es un único archivo HTML. Tiene un filtro por tipo de zona, seis pestañas, mapas
sobre OpenStreetMap, el detalle de cada hotspot con un clic y un simulador de ROI con controles
deslizantes. Es una foto de los datos, sin conexión viva ni credenciales: se puede compartir
como archivo o publicar con `publicar_tablero.sh`, que crea un bucket público aparte del lago.

---

## 13. Pruebas: `tests/` y `tools/`

`generar_muestra_sintetica.py` produce datos con **el mismo formato que la fuente**, con
defectos y un evento inyectados:
- un duplicado;
- una fila corrupta;
- un valor negativo;
- un cuadrante fuera de rango;
- filas parciales;
- un "concierto" de 6× el tráfico normal.

Con esto se prueba cada regla sin gastar en la nube. `test_transformaciones.py` verifica la
regla de validez, la desduplicación en dos pasos, la conversión UTC → Milán con su calendario,
las ventanas de ahorro y la lectura robusta del GeoJSON.
