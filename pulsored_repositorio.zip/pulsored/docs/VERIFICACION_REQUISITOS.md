# Verificación de requisitos del Proyecto Integrador Capstone

Esta matriz contrasta cada requisito del enunciado con el artefacto del repositorio que lo
cumple y con la evidencia que queda en GCP al ejecutar el pipeline. La verificación es
**independiente de los resultados**: lo que se comprueba es que el pipeline produce la
evidencia, no el valor que tome.

Leyenda: ✅ cubierto por el pipeline · 🟡 el pipeline aporta insumos, falta trabajo del equipo.

## 1. Especificaciones de la solución

| Requisito | Estado | Cómo se cumple | Evidencia tras ejecutar |
|---|---|---|---|
| Escala mínima de 15 GB (Parquet, JSON o CSV masivos) | ✅ | 62 archivos TSV diarios de Telecom Italia (Milán), 19.4 GB. La ingesta cuenta los archivos y mide el volumen, y termina con advertencia si hay menos de 62 o menos de 15 GB. El job 02 lo vuelve a medir. | Salida de `descargar_dataverse.sh`; control `requisito_volumen_raw_gb` en `dq_resultado`; tabla `calidad/almacenamiento` |
| Pipeline de extremo a extremo: ingesta | ✅ | `ingest/descargar_dataverse.sh`: API de Dataverse a GCS, con MD5 y manifiesto de linaje. Es idempotente y tiene modo local de respaldo. | `raw/_manifiestos/*.csv` |
| Pipeline: limpieza | ✅ | Job 01: esquema explícito, cuarentena de filas corruptas o fuera de rango, desduplicación en dos pasos, NULL tratado como 0 (documentado), conversión UTC → Europe/Rome. | `staging/cuarentena`, `calidad/dq_raw` |
| Pipeline: transformación (ETL) | ✅ | Jobs 01, 03 y 04: consolidación cuadrante-intervalo, serie horaria densificada, perfiles, presión, ventanas de ahorro (gaps & islands), anomalías (z robusto) y K-Means (MLlib). | `marts/*` |
| Pipeline: optimización de almacenamiento | ✅ | Parquet + Snappy particionado por `dt`; lectura columnar entre jobs; el job 05 compara TSV contra Parquet (agregación completa y consulta selectiva) y mide el factor de compresión. | `calidad/benchmark`, `calidad/almacenamiento` |
| Inteligencia visual para decisiones directivas | ✅ | **Tablero ejecutivo interactivo** (`tablero/`), generado desde MariaDB: filtro por tipo de zona, 6 pestañas, mapas, detalle de hotspots y simulador de ROI. Se puede compartir como enlace. Además, el job 06 genera un reporte HTML con calidad, rendimiento y escalabilidad, y hay 6 vistas SQL para Data Studio (opcional). | `reportes/tablero_pulsored.html`, `reportes/reporte_pulsored.html`, vistas `v_*` |
| Executive pitch de máximo 15 minutos | 🟡 | Queda fuera del pipeline. El reporte HTML y `docs/*.png` sirven como material y demostración en vivo. | — |
| Entregable: repositorio con código y pipelines | ✅ | Este repositorio: 7 jobs, SQL, infraestructura, ingesta y 5 pruebas unitarias. | — |
| Entregable: documento técnico-ejecutivo | 🟡 | Queda fuera del pipeline. Abajo se indica qué evidencia alimenta cada sección. | — |

## 2. Marco estratégico: las 4 preguntas del CDO

| Pregunta | Respuesta del proyecto | Dónde se evidencia |
|---|---|---|
| ¿Qué construimos? | PulsoRed, con tres productos de datos: presión de capacidad por cuadrante, ventanas de ahorro energético y detección de eventos, más una segmentación de zonas. | `marts/`, reporte |
| ¿Para qué? | La red se dimensiona para el pico y se opera igual a toda hora. Hay que priorizar capacidad donde hay presión y apagar capas de capacidad donde el tráfico lo permite. | Reporte, secciones Capacidad y Energía |
| ¿Cómo? | Dataproc efímero orquestado con Workflow Template, lago en GCS por zonas, Spark para el volumen y MariaDB solo para agregados. | `infra/workflow_pulsored.yaml`, `docs/arquitectura.png` |
| ¿A quién beneficia? | Planeación de red, NOC u operación, Finanzas (OPEX de energía) y ESG. El ROI se calcula con las horas elegibles MEDIDAS y supuestos explícitos y editables. | Sección ROI del reporte, `param_roi`, `v_ahorro_estimado` |

## 3. Principios arquitectónicos

| Principio | Decisión concreta |
|---|---|
| KISS ("Tsuru") | Un solo Workflow Template en lugar de Composer o Airflow. Clúster efímero en lugar de uno permanente. Parquet en lugar de Delta o Iceberg (no hay actualizaciones). Sin Kafka (el dato es histórico por lotes). Una VM pequeña de MariaDB. |
| Negocio primero | Cada mart responde una pregunta de operación: dónde ampliar, cuándo apagar y qué fue atípico. |
| Pragmatismo técnico | Solo herramientas del programa (GCP, Dataproc, PySpark, MariaDB/SQL). K-Means y z robusto en lugar de modelos profundos. |
| Sinergia en equipo | Roles naturales: infraestructura (`infra/`, `ingest/`), ingeniería Spark (`jobs/01–05`), SQL y servicio (`sql/`, job 07) y visualización o pitch (job 06, `tablero/`). |

## 4. Competencias técnicas del programa

| Tema del programa | Dónde aparece |
|---|---|
| Infraestructura GCP / Dataproc | `infra/00…03`, Workflow Template, cuenta de servicio con mínimo privilegio, Secret Manager, Private Google Access |
| Optimización de DataFrames en PySpark | Esquema explícito (sin inferSchema), AQE, broadcast del calendario, poda de particiones y columnas, corte de linaje escribiendo y releyendo Parquet, `_metadata.file_name`, funciones de ventana, `percentile_approx` |
| Diseño de esquemas MariaDB/SQL | `sql/01_ddl_mariadb.sql` (llaves compuestas, índices, usuarios con mínimo privilegio, histórico de calidad), `02_vistas_tablero.sql`, `03_kpis_documento.sql` |
| Patrones distribuidos | Desduplicación y consolidación por shuffle, gaps & islands con ventanas, mediana y MAD distribuidos, K-Means en MLlib, carga JDBC por lotes |

## 5. Evidencia por sección del documento técnico

| Sección | Evidencia que genera el pipeline |
|---|---|
| e. Orígenes y control de datos | Manifiesto MD5 (`raw/_manifiestos`), DOIs de origen, columna `archivo` en staging (linaje a nivel fila) |
| f. Preparación de datos | Zonas `raw/` (inmutable), `staging/` y `marts/` en GCS |
| g. Limpieza y tratamiento | `calidad/dq_raw` (nulos, negativos y corruptos por archivo), `staging/cuarentena`, particionamiento `dt=` |
| h. Integridad | `dq_resultado`: 4 controles críticos (quality gate) y 6 de alerta; consulta Q0 de integridad relacional post-carga |
| i. Limitaciones de los datos | `dq_por_dia` (cobertura por día) y alertas de fecha, cobertura y continuidad. Limitaciones estructurales conocidas: unidades escaladas por anonimización, un solo operador, 2 meses de 2013 que incluyen Navidad, cuadrícula en lugar de celdas reales y sesiones de internet registradas solo por encima de 15 min o 5 MB |
| j. Metodología | `docs/arquitectura.png`, `docs/flujo_zonas.png`, Workflow Template |
| k. Pruebas y rendimiento | `calidad/metricas_ejecucion` (segundos y ejecutores por job), `calidad/benchmark`, `calidad/almacenamiento`, corridas `8cores` (perfil `cuota12`) contra `4cores` (perfil `cuota8`) con `infra/03_prueba_escalabilidad.sh`, comparadas en el reporte, event logs de Spark en `spark-events/` y UI vía Component Gateway |
| 5. Resultados e impacto | Reporte HTML, `kpis.json`, consultas Q1–Q10, vistas del tablero, código completo |

## 6. Qué se verificó y qué no

Verificado localmente sobre una **muestra sintética** con el mismo formato (100 cuadrantes × 20 días, con defectos inyectados). Esta muestra sirve solo para probar el código; sus números no son resultados:

- Los 7 jobs corren de principio a fin. El job 07 se emuló: se cargó en MariaDB con las mismas columnas y nombres de tabla que usa el JDBC.
- El quality gate detecta los defectos inyectados: duplicado, fila corrupta, negativo, cuadrante fuera de rango y filas parciales. También alerta correctamente por volumen menor a 15 GB en la muestra.
- La detección de anomalías encuentra el evento inyectado (día 13, 20–23 h, cuadrantes 1–5) y K-Means recupera los 3 perfiles sintéticos.
- El DDL, las 6 vistas y las consultas Q0–Q10 corren sin error en MariaDB 10.11.
- El reporte HTML se genera con y sin matplotlib.
- La ingesta en modo local se probó con un simulador de `gcloud`, incluida la idempotencia.
- Pasan 5 pruebas unitarias y el linter (pyflakes) no reporta problemas.
- El tablero se generó desde MariaDB con los datos sintéticos. Sus 6 pestañas, el filtro, la selección de hotspots y el simulador se ejecutaron sin errores en un navegador simulado (jsdom).
- `infra/02` arma correctamente el workflow para los tres perfiles y para `WORKERS=4`, y bloquea el perfil si la cuota no alcanza. Esto se probó con un simulador de `gcloud`.
- La ingesta completa el flujo de registro de uso contra un servidor que simula Dataverse 6.10+: responde 400, luego POST, URL firmada, descarga, MD5 y manifiesto.

No verificable fuera de tu proyecto, y controlado por el propio pipeline:

| Riesgo | Mitigación incluida |
|---|---|
| Dataverse rechaza la IP de la VM | Modo `local` de la ingesta (descarga en navegador archivo por archivo) |
| Dataverse 6.10+ exige registro de uso (*guestbook*) y responde HTTP 400 a la descarga simple | La ingesta detecta el 400, envía el registro por POST (`DV_NOMBRE`, `DV_EMAIL`, `DV_INSTITUCION`) y descarga desde la URL firmada; si Dataverse lo rechaza, muestra su mensaje exacto |
| Nombre de la propiedad del GeoJSON distinto al esperado | Autodetección (`cellId`, `cellid`, `id`); si no hay coincidencia, error explícito; alerta `centroides_fuera_de_milan` |
| Archivos cortados en día UTC en lugar de día local | Alertas `pct_fecha_distinta_archivo` y cobertura por día (no bloquean) |
| Separador distinto al tabulador | Argumento `--sep`; si fuera incorrecto, la tasa de cuarentena dispara FALLA crítica y el flujo se detiene |
| Imagen de Dataproc sin matplotlib | El reporte sale solo con tablas |
| Cuota global de 12 vCPU (proyectos nuevos) | Perfil predeterminado `cuota12` (10 vCPU + 2 de la VM); `infra/02` revisa `CPUS_ALL_REGIONS` antes de crear el clúster |
| `Access denied` en el usuario del tablero (contraseña o SSL) | `infra/04_restablecer_acceso_tablero.sh` diagnostica ambas causas y renueva la contraseña |
| MariaDB aún no configurada | La carga es el último paso: todo lo demás ya quedó en GCS |
