"""Job 01 - RAW -> STAGING.

Pasada A: perfil de calidad del crudo por archivo (nulos, rangos, corruptos).
Pasada B: cuarentena de filas invalidas (solo si la pasada A detecta alguna).
Pasada C: tipado, conversion horaria, desduplicacion y Parquet particionado por dt.
Paso D:   consolidacion cuadrante-intervalo (lee el Parquet de C, no el crudo).
"""
from datetime import datetime, timezone

from pyspark.sql import functions as F

from common import (ACTIVIDADES, ESQUEMA_RAW, PARAMS, Cronometro, argumentos, borrar, rutas,
                    spark_session)

CLAVE = ["square_id", "time_interval", "country_code"]


def leer_raw(spark, ruta, sep="\t"):
    return (spark.read
            .option("sep", sep)
            .option("header", "false")
            .option("mode", "PERMISSIVE")
            .option("columnNameOfCorruptRecord", "_corrupt_record")
            .schema(ESQUEMA_RAW)
            .csv(ruta)
            .withColumn("archivo", F.col("_metadata.file_name")))


def regla_valida():
    """True solo si la fila es utilizable; los NULL se tratan como invalidos."""
    ok = (F.col("_corrupt_record").isNull()
          & F.col("square_id").between(1, PARAMS["n_cuadrantes"])
          & F.col("time_interval").isNotNull())
    for c in ACTIVIDADES:
        ok = ok & (F.col(c).isNull() | (F.col(c) >= 0))
    return F.coalesce(ok, F.lit(False))


def perfil_calidad_raw(df, id_corrida):
    """Una sola agregacion por archivo; no materializa el crudo."""
    aggs = [F.count(F.lit(1)).alias("filas"),
            F.sum((~regla_valida()).cast("int")).alias("filas_invalidas"),
            F.sum(F.col("_corrupt_record").isNotNull().cast("int")).alias("filas_corruptas")]
    for c in ["square_id", "time_interval", "country_code"] + ACTIVIDADES:
        aggs.append(F.sum(F.col(c).isNull().cast("int")).alias(f"nulos_{c}"))
    for c in ACTIVIDADES:
        aggs.append(F.sum((F.col(c) < 0).cast("int")).alias(f"negativos_{c}"))
    return (df.groupBy("archivo").agg(*aggs)
              .withColumn("id_corrida", F.lit(id_corrida)))


def limpiar(df):
    tz = PARAMS["zona_horaria"]
    validos = (df.filter(regla_valida())
                 .withColumn("country_code", F.coalesce("country_code", F.lit(0))))
    # 1) duplicados exactos: misma clave y mismos valores
    validos = validos.dropDuplicates(CLAVE + ACTIVIDADES)
    # 2) filas parciales de una misma clave se consolidan; NULL = sin actividad = 0
    consolidado = (validos.groupBy(CLAVE).agg(
        *[F.sum(F.coalesce(F.col(c), F.lit(0.0))).alias(c) for c in ACTIVIDADES],
        F.min("archivo").alias("archivo")))
    return (consolidado
            .withColumn("ts_utc", F.expr("timestamp_millis(time_interval)"))
            .withColumn("ts_local", F.from_utc_timestamp("ts_utc", tz))
            .withColumn("dt", F.to_date("ts_local"))
            .drop("time_interval"))


def consolidar_celda(pais):
    """Grano cuadrante x intervalo de 10 min, sumando todos los paises."""
    locales = PARAMS["codigos_locales"]
    festivos = [F.to_date(F.lit(d)) for d in PARAMS["festivos"]]
    voz = F.col("call_in") + F.col("call_out")
    sms = F.col("sms_in") + F.col("sms_out")
    intl = ~F.col("country_code").isin(locales)
    return (pais.groupBy("square_id", "ts_utc", "ts_local", "dt")
            .agg(F.sum("internet").alias("internet"),
                 F.sum(voz).alias("voz"),
                 F.sum(sms).alias("sms"),
                 F.sum(F.when(intl, voz + sms).otherwise(0.0)).alias("voz_sms_intl"))
            .withColumn("hora", F.hour("ts_local"))
            .withColumn("slot", F.col("hora") * 6 + F.floor(F.minute("ts_local") / 10).cast("int"))
            .withColumn("dow", ((F.dayofweek("dt") + 5) % 7) + 1)  # 1 = lunes ... 7 = domingo
            .withColumn("es_festivo", F.col("dt").isin(*festivos)))


def main():
    p = argumentos("RAW -> STAGING")
    p.add_argument("--sep", default="\t", help="separador del crudo (el dataset usa tabulador)")
    args = p.parse_args()
    r = rutas(args.base)
    spark = spark_session("pulsored-01-raw-a-staging")
    crono = Cronometro(spark, args.base, "01_raw_a_staging", args.etiqueta)
    id_corrida = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")

    raw = leer_raw(spark, r["raw"], args.sep)

    # Pasada A: perfil de calidad del crudo
    perfil = perfil_calidad_raw(raw, id_corrida)
    perfil.coalesce(1).write.mode("overwrite").parquet(r["dq_raw"])
    invalidas = spark.read.parquet(r["dq_raw"]).agg(F.sum("filas_invalidas")).first()[0] or 0

    # Pasada B: cuarentena (solo si hace falta; se limpia la de corridas anteriores)
    borrar(spark, r["cuarentena"])
    if invalidas > 0:
        (raw.filter(~regla_valida())
            .withColumn("id_corrida", F.lit(id_corrida))
            .write.mode("overwrite").parquet(r["cuarentena"]))

    # Pasada C: staging por pais, particionado por fecha local
    pais = limpiar(raw)
    (pais.repartition("dt")
         .write.mode("overwrite").partitionBy("dt").parquet(r["stg_pais"]))

    # Paso D: consolidacion desde Parquet (lectura columnar, no del crudo)
    celda = consolidar_celda(spark.read.parquet(r["stg_pais"]))
    (celda.repartition("dt")
          .write.mode("overwrite").partitionBy("dt").parquet(r["stg_celda"]))

    resumen = spark.read.parquet(r["dq_raw"]).agg(F.sum("filas").alias("f"), F.count("archivo").alias("a")).first()
    crono.registrar(archivos=resumen["a"], filas_raw=resumen["f"], filas_invalidas=invalidas,
                    filas_staging_pais=spark.read.parquet(r["stg_pais"]).count(),
                    filas_staging_celda=spark.read.parquet(r["stg_celda"]).count())
    print(f"[01] corrida={id_corrida} filas_invalidas={invalidas}")
    spark.stop()


if __name__ == "__main__":
    main()
