"""Job 05 - Pruebas de rendimiento y optimizacion de almacenamiento (seccion 4.k).

Ejecuta el mismo calculo sobre el crudo TSV y sobre el Parquet de staging:
  B1 agregacion completa : trafico de datos total por dia (lee todo el volumen)
  B2 consulta selectiva  : un cuadrante en un dia (poda de particiones + predicate pushdown)
y mide el tamano de cada zona del lago para obtener el factor de compresion.
Los resultados se ANEXAN con la etiqueta de la corrida (2w, 4w...) para comparar escalabilidad.
"""
import time
from datetime import datetime, timezone

from pyspark.sql import functions as F

from common import ESQUEMA_RAW, PARAMS, Cronometro, argumentos, bytes_en, rutas, spark_session


def medir(fn):
    t = time.time()
    fn()
    return round(time.time() - t, 2)


def main():
    p = argumentos("Benchmark TSV vs Parquet")
    p.add_argument("--sep", default="\t")
    p.add_argument("--dia", default="2013-11-20")
    p.add_argument("--cuadrante", type=int, default=5161)
    args = p.parse_args()
    r = rutas(args.base)
    spark = spark_session("pulsored-05-benchmark")
    crono = Cronometro(spark, args.base, "05_benchmark", args.etiqueta)

    raw = (spark.read.option("sep", args.sep).option("header", "false")
                .schema(ESQUEMA_RAW).csv(r["raw"]))
    stg = spark.read.parquet(r["stg_pais"])
    dt_raw = F.to_date(F.from_utc_timestamp(F.expr("timestamp_millis(time_interval)"),
                                            PARAMS["zona_horaria"]))
    dia = F.to_date(F.lit(args.dia))

    pruebas = {
        ("B1_agregacion_completa", "tsv_raw"):
            lambda: raw.groupBy(dt_raw.alias("dt")).agg(F.sum("internet")).collect(),
        ("B1_agregacion_completa", "parquet_staging"):
            lambda: stg.groupBy("dt").agg(F.sum("internet")).collect(),
        ("B2_consulta_selectiva", "tsv_raw"):
            lambda: raw.filter((dt_raw == dia) & (F.col("square_id") == args.cuadrante))
                       .agg(F.sum("internet")).collect(),
        ("B2_consulta_selectiva", "parquet_staging"):
            lambda: stg.filter((F.col("dt") == dia) & (F.col("square_id") == args.cuadrante))
                       .agg(F.sum("internet")).collect(),
    }
    ahora = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    filas = [(prueba, formato, medir(fn), args.etiqueta, ahora) for (prueba, formato), fn in pruebas.items()]
    (spark.createDataFrame(filas, "prueba string, formato string, segundos double, etiqueta string, medido_utc string")
          .coalesce(1).write.mode("append").parquet(args.base.rstrip("/") + "/calidad/benchmark"))

    zonas = {"raw_tsv": r["raw"], "staging_pais_parquet": r["stg_pais"],
             "staging_celda_parquet": r["stg_celda"], "marts_parquet": r["marts"]}
    tam = [(z, bytes_en(spark, ruta), args.etiqueta, ahora) for z, ruta in zonas.items()]
    (spark.createDataFrame(tam, "zona string, bytes long, etiqueta string, medido_utc string")
          .coalesce(1).write.mode("append").parquet(args.base.rstrip("/") + "/calidad/almacenamiento"))

    factor = tam[0][1] / max(tam[1][1], 1)
    for f in filas:
        print(f"[05] {f[0]:<24} {f[1]:<16} {f[2]:>8} s")
    print(f"[05] compresion raw/staging_pais = {factor:.1f}x")
    crono.registrar(compresion_raw_vs_parquet=round(factor, 2),
                    **{f"{a}_{b}": s for a, b, s, _, _ in filas})
    spark.stop()


if __name__ == "__main__":
    main()
