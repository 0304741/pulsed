"""Job 02 - Quality gate sobre STAGING y catalogo de cuadricula.

Controles criticos (si fallan, el job termina con codigo 1 y el workflow se detiene):
unicidad de llave, integridad referencial, no negativos, tasa de cuarentena.
Controles de alerta (se reportan, no bloquean): cobertura temporal y espacial,
continuidad del calendario, consistencia fecha-archivo.
"""
import sys

from pyspark.sql import functions as F

from common import PARAMS, Cronometro, argumentos, bytes_en, rutas, spark_session


def construir_dim_cuadricula(spark, ruta_geojson):
    """Centroide de cada cuadrante a partir del GeoJSON oficial (WGS 84, EPSG:4326)."""
    gj = spark.read.option("multiLine", True).json(ruta_geojson)
    props = gj.schema["features"].dataType.elementType["properties"].dataType.fieldNames()
    campo = next((c for c in ("cellId", "cellid", "id", "square_id") if c in props), None)
    if campo is None:
        raise ValueError(f"GeoJSON sin identificador de cuadrante reconocible: {props}")
    return (gj.select(F.explode("features").alias("f"))
              .select(F.col(f"f.properties.{campo}").cast("int").alias("square_id"),
                      F.expr("f.geometry.coordinates[0]").alias("anillo"))
              .withColumn("n", F.size("anillo") - 1)  # el anillo repite el primer vertice
              .withColumn("lon", F.expr("aggregate(slice(anillo, 1, n), 0D, (a, p) -> a + p[0]) / n"))
              .withColumn("lat", F.expr("aggregate(slice(anillo, 1, n), 0D, (a, p) -> a + p[1]) / n"))
              .select("square_id", "lat", "lon"))


def evaluar(spark, r, dim):
    """Devuelve la lista de controles (control, valor, umbral, estado, severidad)."""
    celda = spark.read.parquet(r["stg_celda"])
    pais = spark.read.parquet(r["stg_pais"])
    dq_raw = spark.read.parquet(r["dq_raw"])
    n_cuad, spd = PARAMS["n_cuadrantes"], PARAMS["slots_por_dia"]
    res = []

    def reg(control, valor, umbral, ok, severidad):
        res.append((control, float(valor), float(umbral),
                    "OK" if ok else ("FALLA" if severidad == "critica" else "ALERTA"), severidad))

    # Cobertura y continuidad por dia
    por_dia = celda.groupBy("dt").agg(F.countDistinct("slot").alias("slots"),
                                      F.countDistinct("square_id").alias("cuadrantes"))
    s = por_dia.agg(F.min("slots").alias("min_slots"), F.min("cuadrantes").alias("min_cuad"),
                    F.count("dt").alias("dias"), F.min("dt").alias("d0"),
                    F.max("dt").alias("d1")).first()
    dias_esperados = (s["d1"] - s["d0"]).days + 1
    cob_t = s["min_slots"] / spd
    cob_e = s["min_cuad"] / n_cuad
    reg("cobertura_temporal_min_dia", cob_t, PARAMS["umbral_completitud"],
        cob_t >= PARAMS["umbral_completitud"], "alerta")
    reg("cobertura_espacial_min_dia", cob_e, PARAMS["umbral_completitud"],
        cob_e >= PARAMS["umbral_completitud"], "alerta")
    reg("continuidad_calendario_dias", s["dias"], dias_esperados,
        s["dias"] == dias_esperados, "alerta")
    (por_dia.withColumn("cobertura_temporal", F.col("slots") / spd)
            .withColumn("cobertura_espacial", F.col("cuadrantes") / n_cuad)
            .coalesce(1).write.mode("overwrite").parquet(r["dq"] + "_por_dia"))

    # Unicidad de la llave de negocio en staging
    llave = ["square_id", "ts_utc", "country_code"]
    dups = pais.groupBy(llave).count().filter("count > 1").count()
    reg("llaves_duplicadas", dups, 0, dups == 0, "critica")

    # Consistencia fecha local vs fecha del archivo de origen
    f_arch = F.to_date(F.regexp_extract("archivo", r"(\d{4}-\d{2}-\d{2})", 1))
    c = pais.agg(F.avg((F.col("dt") != f_arch).cast("double")).alias("p")).first()["p"] or 0.0
    reg("pct_fecha_distinta_archivo", c, 0.01, c <= 0.01, "alerta")

    # Integridad referencial contra la cuadricula oficial
    huerfanos = (celda.select("square_id").distinct()
                      .join(dim, "square_id", "left_anti").count())
    reg("cuadrantes_sin_geometria", huerfanos, 0, huerfanos == 0, "critica")

    # Rango de valores
    m = celda.agg(F.min(F.least("internet", "voz", "sms")).alias("m")).first()["m"]
    reg("valor_minimo_actividad", m, 0, m >= 0, "critica")

    # Requisito del proyecto: volumen procesado >= 15 GB (solo archivos de actividad)
    gb = bytes_en(spark, r["raw"]) / 1e9  # GB decimales, como los reporta Dataverse
    reg("requisito_volumen_raw_gb", gb, 15, gb >= 15, "alerta")

    # Georreferencia: los centroides deben caer en el area de Milan
    fuera = dim.filter(~(F.col("lat").between(45.2, 45.7) & F.col("lon").between(8.9, 9.5))).count()
    reg("centroides_fuera_de_milan", fuera, 0, fuera == 0, "alerta")

    # Tasa de cuarentena en el crudo
    t = dq_raw.agg((F.sum("filas_invalidas") / F.sum("filas")).alias("t")).first()["t"] or 0.0
    reg("tasa_cuarentena", t, 0.01, t <= 0.01, "critica")
    return res


def main():
    args = argumentos("Quality gate").parse_args()
    r = rutas(args.base)
    spark = spark_session("pulsored-02-calidad")
    crono = Cronometro(spark, args.base, "02_calidad", args.etiqueta)

    dim = construir_dim_cuadricula(spark, r["grid"])
    dim.coalesce(1).write.mode("overwrite").parquet(r["marts"] + "/dim_cuadricula")
    dim = spark.read.parquet(r["marts"] + "/dim_cuadricula")

    res = evaluar(spark, r, dim)
    df = spark.createDataFrame(res, "control string, valor double, umbral double, "
                                    "estado string, severidad string")
    df = df.withColumn("evaluado_en", F.current_timestamp())
    df.coalesce(1).write.mode("overwrite").parquet(r["dq"])
    df.show(truncate=False)

    fallas = [x for x in res if x[3] == "FALLA"]
    crono.registrar(controles=len(res), fallas=len(fallas),
                    alertas=sum(x[3] == "ALERTA" for x in res))
    spark.stop()
    if fallas:
        print(f"[02] QUALITY GATE: {len(fallas)} control(es) critico(s) fallaron: {fallas}")
        sys.exit(1)
    print("[02] QUALITY GATE superado")


if __name__ == "__main__":
    main()
