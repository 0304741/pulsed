"""Job 07 - Publica los marts en MariaDB (capa de servicio del tablero).

Recarga idempotente: overwrite + truncate conserva el DDL (llaves e indices).
El historico de calidad se anexa. La URL usa el esquema jdbc:mysql con el
driver de MariaDB (permitMysqlScheme) para que Spark aplique su dialecto MySQL
(comillas invertidas en identificadores).
"""
import subprocess

from common import Cronometro, argumentos, rutas, spark_session

RECARGA = {  # mart Parquet -> tabla MariaDB
    "cuadrante_enriquecido": "cuadrante",
    "perfil_semanal": "perfil_semanal",
    "ventanas_detalle": "ventana_ahorro",
    "anomalias_detalle": "anomalia",
    "eventos_ciudad": "evento_ciudad",
    "diario_ciudad": "diario_ciudad",
    "cluster_perfil": "cluster_perfil",
    "cluster_resumen": "cluster_resumen",
    "seleccion_k": "seleccion_k",
}


def secreto(nombre: str) -> str:
    """Lee la contrasena de Secret Manager con la cuenta de servicio del cluster."""
    return subprocess.check_output(
        ["gcloud", "secrets", "versions", "access", "latest", f"--secret={nombre}"],
        text=True).strip()


def main():
    p = argumentos("MARTS -> MariaDB")
    p.add_argument("--host", required=True)
    p.add_argument("--usuario", default="pipeline_rw")
    p.add_argument("--secreto", default="pulsored-mariadb-pipeline")
    p.add_argument("--password", default=None, help="solo para pruebas locales")
    args = p.parse_args()
    r = rutas(args.base)
    spark = spark_session("pulsored-07-carga-mariadb")
    crono = Cronometro(spark, args.base, "07_carga_mariadb", args.etiqueta)
    filas = {}

    url = f"jdbc:mysql://{args.host}:3306/pulsored?permitMysqlScheme=true"
    props = {"user": args.usuario,
             "password": args.password or secreto(args.secreto),
             "driver": "org.mariadb.jdbc.Driver",
             "batchsize": "5000"}

    for mart, tabla in RECARGA.items():
        df = spark.read.parquet(f"{r['marts']}/{mart}")
        (df.write.mode("overwrite").option("truncate", "true")
           .jdbc(url, tabla, properties=props))
        filas[tabla] = df.count()
        print(f"[07] {tabla}: {filas[tabla]} filas")

    spark.read.parquet(r["dq"]).write.mode("append").jdbc(url, "dq_resultado", properties=props)
    (spark.read.parquet(r["dq"] + "_por_dia").write.mode("overwrite")
          .option("truncate", "true").jdbc(url, "dq_por_dia", properties=props))
    crono.registrar(**filas)
    spark.stop()


if __name__ == "__main__":
    main()
