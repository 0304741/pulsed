"""Job 06 - Reporte visual ejecutivo (HTML autocontenido) a partir de los marts.

Garantiza el entregable de "Inteligencia Visual" aunque el tablero interactivo
(Looker Studio sobre MariaDB) aun no este configurado. Escribe
{base}/reportes/reporte_pulsored.html con graficas embebidas en base64.
El bloque de ROI usa SUPUESTOS explicitos (argumentos) sobre las horas medidas.
"""
import base64
import io
import json

import pandas as pd
from pyspark.sql import functions as F

from common import Cronometro, argumentos, escribir_texto, rutas, spark_session

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
except ImportError:  # sin matplotlib el reporte se genera solo con tablas
    plt = None

NAVY, TEAL, AMBER, CORAL, GREY = "#1F3A5F", "#2A9D8F", "#E9C46A", "#E76F51", "#6B7280"
DIAS = ["Lun", "Mar", "Mie", "Jue", "Vie", "Sab", "Dom"]


def grafica(dibujar):
    """Ejecuta la funcion de dibujo solo si matplotlib esta disponible."""
    if plt is None:
        return "<p><i>(grafica omitida: matplotlib no disponible en el cluster)</i></p>"
    return png(dibujar())


def png(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=130, bbox_inches="tight")
    plt.close(fig)
    return f'<img src="data:image/png;base64,{base64.b64encode(buf.getvalue()).decode()}">'


def tabla(pdf, decimales=2):
    return pdf.round(decimales).to_html(index=False, border=0, classes="t")


def leer(spark, ruta):
    try:
        return spark.read.parquet(ruta)
    except Exception:  # ruta inexistente (p. ej. benchmark no ejecutado)
        return None


def main():
    p = argumentos("Reporte visual")
    p.add_argument("--sitios", type=float, default=1000, help="SUPUESTO: sitios del area piloto")
    p.add_argument("--kw", type=float, default=1.0, help="SUPUESTO: kW apagables por sitio en ventana")
    p.add_argument("--tarifa", type=float, default=2.5, help="SUPUESTO: MXN por kWh")
    p.add_argument("--realizacion", type=float, default=0.6, help="SUPUESTO: fraccion de horas ejecutadas")
    p.add_argument("--costo-anual", type=float, default=200000, help="SUPUESTO: MXN/anio plataforma + operacion")
    args = p.parse_args()
    r = rutas(args.base)
    m, base = r["marts"], args.base.rstrip("/")
    spark = spark_session("pulsored-06-reporte")
    crono = Cronometro(spark, args.base, "06_reporte_visual", args.etiqueta)

    cuad = spark.read.parquet(m + "/cuadrante_enriquecido").toPandas()
    diario = spark.read.parquet(m + "/diario_ciudad").orderBy("dt").toPandas()
    heat = (spark.read.parquet(m + "/perfil_semanal").groupBy("dow", "hora")
                 .agg(F.sum("internet_media").alias("v")).toPandas()
                 .pivot(index="dow", columns="hora", values="v").sort_index())
    cperf = spark.read.parquet(m + "/cluster_perfil").toPandas()
    cres = spark.read.parquet(m + "/cluster_resumen").toPandas()
    selk = spark.read.parquet(m + "/seleccion_k").orderBy("k").toPandas()
    eventos = spark.read.parquet(m + "/eventos_ciudad").orderBy("dt", "hora").toPandas()
    dq = spark.read.parquet(r["dq"]).toPandas()
    metr = spark.read.json(base + "/calidad/metricas_ejecucion").toPandas()
    bench, alm = leer(spark, base + "/calidad/benchmark"), leer(spark, base + "/calidad/almacenamiento")

    act = cuad[cuad["cluster"] >= 0]
    hot = act[act["es_hotspot"] == True]  # noqa: E712
    pct_hot = 100 * hot["trafico_hora_pico"].sum() / act["trafico_hora_pico"].sum()
    h_sem = act["horas_elegibles_semana"].mean()
    kwh = args.sitios * args.kw * h_sem * 52 * args.realizacion
    ahorro = kwh * args.tarifa
    kpis = {"Cuadrantes con actividad": f"{len(act):,}", "Hotspots (top 5 % de presion)": f"{len(hot):,}",
            "Trafico de hora pico en hotspots": f"{pct_hot:.1f} %",
            "Horas elegibles de ahorro por semana (prom.)": f"{h_sem:.1f} h",
            "Eventos hora-ciudad detectados (>= 5 cuadrantes)": f"{int((eventos['cuadrantes_anomalos'] >= 5).sum())}",
            "Ahorro anual estimado (escenario de supuestos)": f"${ahorro:,.0f} MXN"}

    secciones = []

    # 1. Tendencia diaria
    def g_tendencia():
        fig, ax = plt.subplots(figsize=(11, 3.4))
        for col, color in (("internet", NAVY), ("voz", TEAL)):
            ax.plot(diario["dt"], 100 * diario[col] / diario[col].mean(), color=color, lw=2, label=col)
        for _, f in diario[diario["es_festivo"]].iterrows():
            ax.axvline(f["dt"], color=CORAL, ls=":", lw=1)
        ax.set_ylabel("indice (media = 100)"); ax.legend(frameon=False); ax.grid(alpha=.3)
        return fig
    secciones.append(("Tendencia diaria de la ciudad", "Lineas punteadas: festivos.", grafica(g_tendencia)))

    # 2 y 3. Mapas
    def g_mapas():
        fig, axs = plt.subplots(1, 2, figsize=(11, 4.6))
        s0 = axs[0].scatter(act["lon"], act["lat"], c=act["indice_presion"], cmap="YlOrRd", s=6, marker="s")
        axs[0].scatter(hot["lon"], hot["lat"], facecolors="none", edgecolors=NAVY, s=14, marker="s", lw=.8)
        axs[0].set_title("Indice de presion (borde azul = hotspot)"); fig.colorbar(s0, ax=axs[0])
        s1 = axs[1].scatter(act["lon"], act["lat"], c=act["horas_elegibles_semana"], cmap="Greens", s=6, marker="s")
        axs[1].set_title("Horas elegibles de ahorro por semana"); fig.colorbar(s1, ax=axs[1])
        for a in axs:
            a.set_xticks([]); a.set_yticks([]); a.set_aspect("equal")
        return fig
    top_hot = hot.sort_values("indice_presion", ascending=False)[
        ["square_id", "hora_pico", "trafico_hora_pico", "indice_presion", "horas_elegibles_semana"]].head(20)
    secciones.append(("Capacidad y energia por cuadrante", "Tabla: 20 hotspots de mayor presion.",
                      grafica(g_mapas) + tabla(top_hot)))

    # 4. Mapa de calor semanal
    def g_calor():
        fig, ax = plt.subplots(figsize=(11, 3))
        im = ax.imshow(heat.values, aspect="auto", cmap="Blues")
        ax.set_yticks(range(len(heat.index))); ax.set_yticklabels([DIAS[int(d) - 1] for d in heat.index])
        ax.set_xticks(range(0, 24, 2)); ax.set_xlabel("hora local"); fig.colorbar(im, ax=ax)
        return fig
    secciones.append(("Semana tipica de la ciudad (trafico de datos)", "", grafica(g_calor)))

    # 5. Segmentos
    etiquetas = dict(zip(cres["cluster"], cres["etiqueta_sugerida"]))

    def g_segmentos():
        fig, axs = plt.subplots(1, 2, figsize=(11, 3.4), sharey=True)
        for i, tipo in enumerate(("lab", "fds")):
            for c, g in cperf[cperf["tipo_dia"] == tipo].groupby("cluster"):
                g = g.sort_values("hora")
                axs[i].plot(g["hora"], g["valor_norm"], lw=2, label=f"{c}: {etiquetas.get(c, '')}")
            axs[i].set_title("Dia laboral" if tipo == "lab" else "Fin de semana"); axs[i].grid(alpha=.3)
        axs[0].set_ylabel("trafico / media del cuadrante"); axs[1].legend(frameon=False, fontsize=8)
        return fig
    secciones.append(("Perfiles de los segmentos (K-Means)",
                      "Etiquetas sugeridas por reglas; validarlas con el mapa antes de usarlas.",
                      grafica(g_segmentos) + tabla(cres) + tabla(selk, 4)))

    # 6. Eventos
    def g_eventos():
        fig, ax = plt.subplots(figsize=(11, 2.8))
        ev = eventos.assign(ts=eventos["dt"].astype(str) + " " + eventos["hora"].astype(str) + "h")
        ax.bar(range(len(ev)), ev["cuadrantes_anomalos"], color=CORAL)
        paso = max(len(ev) // 12, 1)
        ax.set_xticks(range(0, len(ev), paso))
        ax.set_xticklabels(ev["ts"][::paso], rotation=45, ha="right", fontsize=7)
        ax.set_ylabel("cuadrantes anomalos")
        return fig
    top = eventos.sort_values(["cuadrantes_anomalos", "z_max"], ascending=False).head(10)
    secciones.append(("Eventos detectados (z robusto >= 4)", "", grafica(g_eventos) + tabla(top)))

    # 7. ROI (supuestos explicitos)
    sens = [(h, k, round(args.sitios * k * h * 52 * args.realizacion * args.tarifa))
            for h in (h_sem * .5, h_sem, h_sem * 1.5) for k in (args.kw * .5, args.kw, args.kw * 1.5)]
    sens = pd.DataFrame(sens, columns=["horas_semana", "kW_por_sitio", "ahorro_MXN_anual"])
    roi = (ahorro - args.costo_anual) / args.costo_anual
    supuestos = (f"Supuestos: {args.sitios:,.0f} sitios, {args.kw} kW apagables, tarifa {args.tarifa} MXN/kWh, "
                 f"realizacion {args.realizacion:.0%}, costo anual {args.costo_anual:,.0f} MXN. "
                 f"Horas elegibles MEDIDAS: {h_sem:.1f} h/semana. ROI = {roi:.1f} veces.")
    secciones.append(("Modelo de ROI y sensibilidad", supuestos, tabla(sens, 1)))

    # 8. Calidad de datos
    secciones.append(("Calidad de datos (ultimo quality gate)", "",
                      tabla(dq[["control", "valor", "umbral", "estado", "severidad"]], 4)))

    # 9. Rendimiento y escalabilidad: ultima medicion de cada job por etiqueta de corrida
    ult = (metr.sort_values("inicio_utc").groupby(["job", "etiqueta"], as_index=False).last())
    tiempos = ult.pivot(index="job", columns="etiqueta", values="segundos").sort_index()

    def g_tiempos():
        fig, ax = plt.subplots(figsize=(10, 3.6))
        (tiempos / 60).plot.barh(ax=ax, color=[TEAL, CORAL, NAVY, AMBER, GREY][:len(tiempos.columns)])
        ax.invert_yaxis(); ax.set_xlabel("minutos"); ax.set_ylabel(""); ax.grid(axis="x", alpha=.3)
        ax.legend(title="corrida", frameon=False)
        return fig
    rend = grafica(g_tiempos) + tabla((tiempos / 60).round(2).reset_index(), 2)
    if tiempos.shape[1] > 1:
        tot = (tiempos.sum() / 60).round(1)
        rend = f"<p>Tiempo total de los jobs por corrida (min): {', '.join(f'{k}: {v}' for k, v in tot.items())}.</p>" + rend
    if bench is not None:
        b = bench.toPandas()

        def g_bench():
            fig, ax = plt.subplots(figsize=(10, 3.2))
            piv = b.sort_values("medido_utc").groupby(["prueba", "formato", "etiqueta"])["segundos"].last().unstack(["formato", "etiqueta"])
            piv.columns = [f"{f} ({e})" for f, e in piv.columns]
            piv.plot.bar(ax=ax, rot=0); ax.set_ylabel("segundos"); ax.legend(frameon=False, fontsize=8)
            return fig
        rend += "<h3>Benchmark TSV contra Parquet</h3>" + grafica(g_bench) + tabla(b)
    if alm is not None:
        a = alm.toPandas().sort_values("medido_utc").groupby("zona", as_index=False).last()
        a["GB"] = a["bytes"] / 1e9
        rend += "<h3>Tamano por zona del lago</h3>" + tabla(a[["zona", "GB", "medido_utc"]], 3)
    rend += "<h3>Bitacora completa de ejecuciones</h3>" + tabla(metr[["job", "etiqueta", "inicio_utc", "segundos", "ejecutores_activos", "extra"]])
    secciones.append(("Rendimiento y escalabilidad",
                      "Cada corrida se identifica por sus nucleos de trabajo (p. ej. 8cores, 4cores).", rend))

    tarjetas = "".join(f'<div class="k"><b>{v}</b><span>{k}</span></div>' for k, v in kpis.items())
    cuerpo = "".join(f"<h2>{t}</h2><p>{d}</p>{c}" for t, d, c in secciones)
    html = f"""<!doctype html><html lang="es"><meta charset="utf-8">
<title>PulsoRed - Reporte ejecutivo</title>
<style>body{{font-family:Arial,sans-serif;max-width:1150px;margin:24px auto;color:#1f2937}}
h1{{color:{NAVY}}} h2{{color:{NAVY};border-bottom:2px solid {TEAL};padding-bottom:4px;margin-top:34px}}
.ks{{display:flex;flex-wrap:wrap;gap:10px}} .k{{flex:1 1 170px;background:#EEF2F7;border-radius:8px;padding:12px}}
.k b{{display:block;font-size:22px;color:{NAVY}}} .k span{{font-size:12px;color:{GREY}}}
img{{max-width:100%}} table.t{{border-collapse:collapse;font-size:12px;margin:10px 0}}
table.t th{{background:{NAVY};color:#fff;padding:4px 8px}} table.t td{{border-bottom:1px solid #ddd;padding:3px 8px}}
p{{color:{GREY};font-size:13px}}</style>
<h1>PulsoRed - Reporte ejecutivo</h1><p>Corrida: {args.etiqueta}. Datos: Telecom Italia Big Data Challenge, Milan.</p>
<div class="ks">{tarjetas}</div>{cuerpo}</html>"""
    destino = base + "/reportes/reporte_pulsored.html"
    escribir_texto(spark, destino, html)
    escribir_texto(spark, base + "/reportes/kpis.json", json.dumps(kpis, ensure_ascii=False, indent=2))
    crono.registrar(reporte=destino)
    print(f"[06] reporte en {destino}")
    spark.stop()


if __name__ == "__main__":
    main()
