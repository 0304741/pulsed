"""Job 04 - Segmentacion de cuadrantes por forma del perfil de uso (K-Means, Spark MLlib).

Cada cuadrante se describe con 48 valores: trafico de datos medio por hora en dia
laboral (24) y en fin de semana (24), dividido entre su propia media. Se compara la
FORMA del uso (cuando se usa la red), no el volumen (cuanto se usa).
"""
from pyspark.ml.clustering import KMeans
from pyspark.ml.evaluation import ClusteringEvaluator
from pyspark.ml.feature import VectorAssembler
from pyspark.sql import functions as F

from common import Cronometro, argumentos, div, rutas, spark_session

CLAVES = [f"{t}_{h:02d}" for t in ("lab", "fds") for h in range(24)]


def matriz_perfiles(perfil):
    x = (perfil.withColumn("tipo", F.when(F.col("dow") <= 5, "lab").otherwise("fds"))
               .groupBy("square_id", "tipo", "hora").agg(F.avg("internet_media").alias("v"))
               .withColumn("clave", F.concat_ws("_", "tipo", F.lpad(F.col("hora").cast("string"), 2, "0"))))
    ancha = x.groupBy("square_id").pivot("clave", CLAVES).agg(F.first("v")).na.fill(0.0)
    media = sum(F.col(c) for c in CLAVES) / len(CLAVES)
    ancha = ancha.withColumn("media", media).filter(F.col("media") > 0)
    for c in CLAVES:
        ancha = ancha.withColumn(c, div(F.col(c), F.col("media")))
    return VectorAssembler(inputCols=CLAVES, outputCol="features").transform(ancha)


def elegir_k(datos, k_min, k_max, semilla=42):
    evaluador = ClusteringEvaluator(featuresCol="features", metricName="silhouette")
    resultados, mejor = [], None
    for k in range(k_min, k_max + 1):
        modelo = KMeans(k=k, seed=semilla, featuresCol="features").fit(datos)
        sil = evaluador.evaluate(modelo.transform(datos))
        resultados.append((k, float(sil)))
        if mejor is None or sil > mejor[1]:
            mejor = (modelo, sil, k)
    return mejor, resultados


def etiquetar(perfiles_cluster):
    """Etiqueta SUGERIDA por reglas simples; el equipo la valida con el mapa."""
    return perfiles_cluster.withColumn(
        "etiqueta_sugerida",
        F.when(F.col("ratio_fds_lab") < 0.75, "Oficinas / negocios")
         .when(F.col("pct_nocturno") > 0.20, "Ocio nocturno")
         .when(F.col("ratio_fds_lab") > 1.05, "Ocio / comercio de fin de semana")
         .otherwise("Residencial / mixto"))


def main():
    p = argumentos("Segmentacion K-Means")
    p.add_argument("--k-min", type=int, default=3)
    p.add_argument("--k-max", type=int, default=8)
    args = p.parse_args()
    r = rutas(args.base)
    m = r["marts"]
    spark = spark_session("pulsored-04-segmentacion")
    crono = Cronometro(spark, args.base, "04_segmentacion", args.etiqueta)

    datos = matriz_perfiles(spark.read.parquet(m + "/perfil_semanal")).cache()
    (modelo, sil, k), curva = elegir_k(datos, args.k_min, args.k_max)
    spark.createDataFrame(curva, "k int, silhouette double") \
         .coalesce(1).write.mode("overwrite").parquet(m + "/seleccion_k")

    asignado = modelo.transform(datos).select("square_id", F.col("prediction").alias("cluster"), *CLAVES)

    # Perfil medio de cada cluster (formato largo para graficar) e indicadores para etiquetar
    largo = asignado.select("square_id", "cluster", F.explode(F.array(*[
        F.struct(F.lit(c).alias("clave"), F.col(c).alias("valor")) for c in CLAVES])).alias("e"))
    largo = (largo.select("cluster", F.split("e.clave", "_").getItem(0).alias("tipo_dia"),
                          F.split("e.clave", "_").getItem(1).cast("int").alias("hora"),
                          F.col("e.valor").alias("valor"))
                  .groupBy("cluster", "tipo_dia", "hora").agg(F.avg("valor").alias("valor_norm")))
    largo.coalesce(1).write.mode("overwrite").parquet(m + "/cluster_perfil")

    lab = sum(F.col(f"lab_{h:02d}") for h in range(24))
    fds = sum(F.col(f"fds_{h:02d}") for h in range(24))
    noct = sum(F.col(f"lab_{h:02d}") + F.col(f"fds_{h:02d}") for h in list(range(0, 5)) + [22, 23])
    indicadores = (asignado.groupBy("cluster")
                   .agg(F.count(F.lit(1)).alias("n_cuadrantes"),
                        F.avg(div(fds, lab)).alias("ratio_fds_lab"),
                        F.avg(noct / (lab + fds)).alias("pct_nocturno")))
    etiquetar(indicadores).coalesce(1).write.mode("overwrite").parquet(m + "/cluster_resumen")

    # Dimension enriquecida para el mapa del tablero
    dim = spark.read.parquet(m + "/dim_cuadricula")
    enriquecida = (dim.join(asignado.select("square_id", "cluster"), "square_id", "left")
                      .join(spark.read.parquet(m + "/presion_capacidad"), "square_id", "left")
                      .join(spark.read.parquet(m + "/ventanas_resumen"), "square_id", "left")
                      .na.fill({"cluster": -1}))
    enriquecida.coalesce(1).write.mode("overwrite").parquet(m + "/cuadrante_enriquecido")
    crono.registrar(k=k, silhouette=round(float(sil), 4), cuadrantes=datos.count())
    print(f"[04] k elegido={k} silhouette={sil:.3f}")
    spark.stop()


if __name__ == "__main__":
    main()
