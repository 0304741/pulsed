"""Job 03 - STAGING -> MARTS analiticos.

Marts: serie horaria densificada, perfil semanal tipico, presion de capacidad,
ventanas de ahorro energetico, anomalias/eventos y tendencia diaria de ciudad.
"""
from pyspark.sql import Window
from pyspark.sql import functions as F

from common import PARAMS, Cronometro, argumentos, div, rutas, spark_session

LLAVE_PERFIL = ["square_id", "dow", "hora"]


def serie_horaria(celda):
    """Agrega a hora y densifica: una hora sin registros de un cuadrante vale 0.
    Solo se densifican horas que existen a nivel ciudad (no se inventan apagones)."""
    h = (celda.groupBy("square_id", "dt", "hora")
              .agg(F.sum("internet").alias("internet"), F.sum("voz").alias("voz"),
                   F.sum("sms").alias("sms"), F.sum("voz_sms_intl").alias("voz_sms_intl")))
    horas_ciudad = celda.select("dt", "hora", "dow", "es_festivo").distinct()
    cuadrantes = celda.select("square_id").distinct()
    esqueleto = cuadrantes.crossJoin(F.broadcast(horas_ciudad))
    return (esqueleto.join(h, ["square_id", "dt", "hora"], "left")
                     .na.fill(0.0, ["internet", "voz", "sms", "voz_sms_intl"]))


def filtro_tipico(ini, fin):
    return F.col("dt").between(F.to_date(F.lit(ini)), F.to_date(F.lit(fin))) & ~F.col("es_festivo")


def perfil_semanal(h, tipico):
    return (h.filter(tipico).groupBy(LLAVE_PERFIL).agg(
        F.avg("internet").alias("internet_media"),
        F.expr("percentile_approx(internet, 0.95)").alias("internet_p95"),
        F.avg("voz").alias("voz_media"),
        F.expr("percentile_approx(voz, 0.95)").alias("voz_p95"),
        F.avg("sms").alias("sms_media"),
        F.count(F.lit(1)).alias("n_dias")))


def presion_capacidad(perfil):
    lab = (perfil.filter(F.col("dow") <= 5).groupBy("square_id", "hora")
                 .agg(F.avg("internet_media").alias("bh_media"),
                      F.max("internet_p95").alias("bh_p95"),
                      F.avg("voz_media").alias("bh_voz")))
    w = Window.partitionBy("square_id").orderBy(F.desc("bh_media"), F.asc("hora"))
    pico = (lab.withColumn("rk", F.row_number().over(w)).filter("rk = 1")
               .select("square_id", F.col("hora").alias("hora_pico"),
                       F.col("bh_media").alias("trafico_hora_pico"),
                       F.col("bh_p95").alias("trafico_hora_pico_p95")))
    voz_pico = lab.groupBy("square_id").agg(F.max("bh_voz").alias("voz_hora_pico"))
    medio = perfil.groupBy("square_id").agg(F.avg("internet_media").alias("trafico_medio"))
    # 10 000 filas: un percent_rank global sin particion es aceptable a esta escala
    ciudad = Window.orderBy("trafico_hora_pico_p95")
    return (pico.join(voz_pico, "square_id").join(medio, "square_id")
                .withColumn("ratio_pico_medio",
                            div(F.col("trafico_hora_pico"), F.col("trafico_medio")))
                .withColumn("indice_presion", F.round(F.percent_rank().over(ciudad) * 100, 1))
                .withColumn("es_hotspot",
                            F.col("indice_presion") >= PARAMS["percentil_hotspot"] * 100))


def ventanas_ahorro(perfil, presion):
    """Horas de la semana en que incluso el p95 del trafico esta por debajo de
    alfa x hora pico (datos y voz). Se agrupan horas consecutivas (gaps & islands)."""
    alfa, minh = PARAMS["alfa_ahorro"], PARAMS["min_horas_ventana"]
    p = (perfil.join(presion.select("square_id", "trafico_hora_pico", "voz_hora_pico"), "square_id")
               .withColumn("how", (F.col("dow") - 1) * 24 + F.col("hora"))
               .withColumn("elegible",
                           (F.col("trafico_hora_pico") > 0)
                           & (F.col("internet_p95") <= alfa * F.col("trafico_hora_pico"))
                           & (F.col("voz_p95") <= alfa * F.col("voz_hora_pico"))))
    w = Window.partitionBy("square_id").orderBy("how")
    islas = (p.filter("elegible")
              .withColumn("grupo", F.col("how") - F.row_number().over(w))
              .groupBy("square_id", "grupo")
              .agg(F.min("how").alias("inicio_how"), F.count(F.lit(1)).alias("duracion_h"))
              .filter(F.col("duracion_h") >= minh)
              .withColumn("dia_inicio", F.floor(F.col("inicio_how") / 24).cast("int") + 1)
              .withColumn("hora_inicio", (F.col("inicio_how") % 24).cast("int"))
              .drop("grupo"))
    resumen = (islas.groupBy("square_id")
                    .agg(F.sum("duracion_h").alias("horas_elegibles_semana"),
                         F.count(F.lit(1)).alias("n_ventanas")))
    resumen = (presion.select("square_id").join(resumen, "square_id", "left")
                      .na.fill(0, ["horas_elegibles_semana", "n_ventanas"])
                      .withColumn("pct_semana_elegible",
                                  F.round(F.col("horas_elegibles_semana") / 168, 4)))
    return islas, resumen


def anomalias(h, tipico):
    """z robusto por cuadrante x dia de semana x hora (mediana y MAD del periodo tipico)."""
    base = h.filter(tipico)
    med = base.groupBy(LLAVE_PERFIL).agg(F.expr("percentile_approx(internet, 0.5)").alias("mediana"))
    mad = (base.join(med, LLAVE_PERFIL)
               .withColumn("desv", F.abs(F.col("internet") - F.col("mediana")))
               .groupBy(LLAVE_PERFIL).agg(F.expr("percentile_approx(desv, 0.5)").alias("mad")))
    ref = med.join(mad, LLAVE_PERFIL)
    z = (h.join(ref, LLAVE_PERFIL)
          # piso de escala: 5 % de la mediana evita z infinitos cuando el MAD es ~0
          .withColumn("escala", F.greatest(1.4826 * F.col("mad"), 0.05 * F.col("mediana"), F.lit(1e-6)))
          .withColumn("z", (F.col("internet") - F.col("mediana")) / F.col("escala"))
          .withColumn("exceso_pct", div(F.col("internet"), F.col("mediana")) - 1))
    detalle = (z.filter((F.col("z") >= PARAMS["z_anomalia"]) & (F.col("mediana") > 0)
                        & (F.col("exceso_pct") >= 0.5))
                .select("square_id", "dt", "hora", "dow", "es_festivo", "internet",
                        "mediana", F.round("z", 2).alias("z"), F.round("exceso_pct", 3).alias("exceso_pct")))
    eventos = (detalle.groupBy("dt", "hora")
                      .agg(F.count(F.lit(1)).alias("cuadrantes_anomalos"),
                           F.sum(F.col("internet") - F.col("mediana")).alias("exceso_total"),
                           F.max("z").alias("z_max")))
    return detalle, eventos


def diario_ciudad(celda):
    return (celda.groupBy("dt", "dow", "es_festivo")
                 .agg(F.sum("internet").alias("internet"), F.sum("voz").alias("voz"),
                      F.sum("sms").alias("sms"), F.sum("voz_sms_intl").alias("voz_sms_intl"))
                 .withColumn("pct_internacional",
                             F.round(div(F.col("voz_sms_intl"), F.col("voz") + F.col("sms")), 4)))


def escribir(df, ruta, archivos=1):
    df.coalesce(archivos).write.mode("overwrite").parquet(ruta)


def main():
    args = argumentos("STAGING -> MARTS").parse_args()
    r = rutas(args.base)
    spark = spark_session("pulsored-03-marts")
    crono = Cronometro(spark, args.base, "03_marts", args.etiqueta)
    m = r["marts"]

    celda = spark.read.parquet(r["stg_celda"])
    h = serie_horaria(celda)
    h.write.mode("overwrite").partitionBy("dt").parquet(m + "/serie_horaria")
    h = spark.read.parquet(m + "/serie_horaria")  # corta el linaje; lectura columnar
    tipico = filtro_tipico(args.tipico_inicio, args.tipico_fin)

    escribir(perfil_semanal(h, tipico), m + "/perfil_semanal", 4)
    perfil = spark.read.parquet(m + "/perfil_semanal").cache()

    escribir(presion_capacidad(perfil), m + "/presion_capacidad")
    presion = spark.read.parquet(m + "/presion_capacidad")

    islas, resumen = ventanas_ahorro(perfil, presion)
    escribir(islas, m + "/ventanas_detalle")
    escribir(resumen, m + "/ventanas_resumen")

    detalle, eventos = anomalias(h, tipico)
    escribir(detalle, m + "/anomalias_detalle")
    escribir(eventos, m + "/eventos_ciudad")

    escribir(diario_ciudad(celda), m + "/diario_ciudad")
    crono.registrar(filas_serie_horaria=h.count(), filas_perfil=perfil.count(),
                    anomalias=spark.read.parquet(m + "/anomalias_detalle").count())
    print("[03] marts generados")
    spark.stop()


if __name__ == "__main__":
    main()
