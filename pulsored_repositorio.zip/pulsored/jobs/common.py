"""Utilidades y parametros compartidos por los jobs de PulsoRed."""
import argparse
import json
import time
from datetime import datetime, timezone

from pyspark.sql import SparkSession
from pyspark.sql import types as T

# Columnas de actividad del dataset (unidades anonimizadas, proporcionales a eventos)
ACTIVIDADES = ["sms_in", "sms_out", "call_in", "call_out", "internet"]

# Esquema explicito: evita inferSchema (una pasada extra sobre 19 GB) y fija tipos
ESQUEMA_RAW = T.StructType([
    T.StructField("square_id", T.IntegerType()),
    T.StructField("time_interval", T.LongType()),      # epoch en ms (UTC)
    T.StructField("country_code", T.IntegerType()),
    T.StructField("sms_in", T.DoubleType()),
    T.StructField("sms_out", T.DoubleType()),
    T.StructField("call_in", T.DoubleType()),
    T.StructField("call_out", T.DoubleType()),
    T.StructField("internet", T.DoubleType()),
    T.StructField("_corrupt_record", T.StringType()),  # filas mal formadas
])

# Parametros de negocio (versionados junto con el codigo)
PARAMS = {
    "zona_horaria": "Europe/Rome",
    "n_cuadrantes": 10000,
    "slots_por_dia": 144,                     # intervalos de 10 minutos
    "codigos_locales": [39, 0],               # 39 = Italia, 0 = no identificado
    "festivos": ["2013-11-01", "2013-12-07", "2013-12-08",
                 "2013-12-25", "2013-12-26", "2014-01-01"],
    # Periodo "tipico" para linea base: semanas completas sin temporada navidena
    "tipico_inicio": "2013-11-04",
    "tipico_fin": "2013-12-22",
    "percentil_hotspot": 0.95,                # top 5 % de presion = hotspot
    "alfa_ahorro": 0.15,                      # umbral relativo a la hora pico
    "min_horas_ventana": 2,                   # duracion minima de una ventana de ahorro
    "z_anomalia": 4.0,                        # umbral de z robusto
    "umbral_completitud": 0.97,               # quality gate
}


def spark_session(app: str) -> SparkSession:
    return (SparkSession.builder.appName(app)
            .config("spark.sql.session.timeZone", "UTC")
            .config("spark.sql.adaptive.enabled", "true")
            .config("spark.sql.adaptive.coalescePartitions.enabled", "true")
            .config("spark.sql.sources.partitionOverwriteMode", "dynamic")
            .config("spark.sql.parquet.compression.codec", "snappy")
            .getOrCreate())


def argumentos(desc: str) -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description=desc)
    p.add_argument("--base", required=True,
                   help="Ruta base del lago, p. ej. gs://pulsored-lake o /tmp/lake")
    p.add_argument("--tipico-inicio", default=PARAMS["tipico_inicio"])
    p.add_argument("--tipico-fin", default=PARAMS["tipico_fin"])
    p.add_argument("--etiqueta", default="local",
                   help="etiqueta de la corrida para comparar escalabilidad (p. ej. 4cores, 8cores)")
    return p


def bytes_en(spark, ruta: str) -> int:
    """Tamano total de una ruta (local, HDFS o gs://) via la API de Hadoop."""
    jvm = spark.sparkContext._jvm
    p = jvm.org.apache.hadoop.fs.Path(ruta)
    fs = p.getFileSystem(spark.sparkContext._jsc.hadoopConfiguration())
    return int(fs.getContentSummary(p).getLength()) if fs.exists(p) else 0


def borrar(spark, ruta: str) -> None:
    """Elimina una ruta si existe (p. ej. cuarentena de una corrida anterior)."""
    jvm = spark.sparkContext._jvm
    p = jvm.org.apache.hadoop.fs.Path(ruta)
    fs = p.getFileSystem(spark.sparkContext._jsc.hadoopConfiguration())
    if fs.exists(p):
        fs.delete(p, True)


def escribir_texto(spark, ruta: str, texto: str) -> None:
    """Escribe un archivo de texto (HTML, JSON) en local o gs:// sin dependencias extra."""
    jvm = spark.sparkContext._jvm
    p = jvm.org.apache.hadoop.fs.Path(ruta)
    fs = p.getFileSystem(spark.sparkContext._jsc.hadoopConfiguration())
    out = fs.create(p, True)
    out.write(bytearray(texto.encode("utf-8")))
    out.close()


class Cronometro:
    """Mide la duracion de un job y la anexa a calidad/metricas_ejecucion (seccion 4.k)."""

    def __init__(self, spark, base: str, job: str, etiqueta: str):
        self.spark, self.base, self.job, self.etiqueta = spark, base.rstrip("/"), job, etiqueta
        self.t0, self.inicio = time.time(), datetime.now(timezone.utc)

    def registrar(self, **extra):
        sc = self.spark.sparkContext
        fila = {
            "job": self.job, "etiqueta": self.etiqueta,
            "inicio_utc": self.inicio.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "segundos": round(time.time() - self.t0, 1),
            "spark_version": self.spark.version,
            "default_parallelism": sc.defaultParallelism,
            "ejecutores_activos": max(sc._jsc.sc().getExecutorMemoryStatus().size() - 1, 1),
            "extra": json.dumps(extra, default=str),
        }
        (self.spark.createDataFrame([fila]).coalesce(1)
             .write.mode("append").json(f"{self.base}/calidad/metricas_ejecucion"))
        print(f"[metrica] {fila}")


def div(a, b):
    """Division segura: NULL si el denominador es 0 (compatible con modo ANSI)."""
    from pyspark.sql import functions as F
    return F.when(b != 0, a / b)


def rutas(base: str) -> dict:
    base = base.rstrip("/")
    return {
        "raw": f"{base}/raw/telecom",
        "grid": f"{base}/raw/grid/milano-grid.geojson",
        "stg_pais": f"{base}/staging/actividad_pais",
        "stg_celda": f"{base}/staging/actividad_celda",
        "cuarentena": f"{base}/staging/cuarentena",
        "dq_raw": f"{base}/calidad/dq_raw",
        "dq": f"{base}/calidad/dq_resultados",
        "marts": f"{base}/marts",
    }
