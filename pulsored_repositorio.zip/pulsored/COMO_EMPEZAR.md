# Cómo empezar: PulsoRed en Google Cloud, paso a paso

Esta guía parte de cero. Dice dónde se escribe cada comando, qué hace y cómo comprobar
que salió bien antes de pasar al siguiente paso.

## Lo primero: ¿dónde se ejecuta cada cosa?

**No necesitas crear ninguna VM a mano.** Todo se controla desde **Cloud Shell**, una
terminal que Google te da gratis dentro del navegador. Cloud Shell ya trae `gcloud`
instalado y con tu sesión iniciada. Los scripts crean las demás piezas por ti.

| Pieza | Qué es | Quién la crea | Dónde vive |
|---|---|---|---|
| **Cloud Shell** | Tu terminal de control; desde aquí lanzas todos los scripts | Ya existe | Navegador (consola de GCP) |
| **Buckets** `TU-PROYECTO-pulsored-lake` y `-code` | El lago de datos (raw, staging, marts) y el código | `infra/00` | Cloud Storage |
| **VM `pulsored-mariadb`** | La base de datos MariaDB del tablero; también descarga los 19.4 GB | `infra/00` | Compute Engine |
| **Clúster Dataproc** | Las máquinas que corren Spark | `infra/02`, en cada corrida | Se crea al empezar y **se borra solo** al terminar |

```
  Tú (navegador)
      │
      ▼
  CLOUD SHELL ──── bash infra/00 ...  ──► crea buckets, VM, permisos
      │
      ├──────── bash infra/01 ...  ──► configura MariaDB dentro de la VM
      ├──────── bash ingest/lanzar_en_vm.sh ──► la VM descarga 19.4 GB al bucket
      └──────── bash infra/02 ...  ──► Dataproc (temporal) procesa y publica resultados
```

**Resumen del orden:** paso 0 (preparar el proyecto) → 1 (Cloud Shell y archivos) →
2 (`infra/00`) → 3 (`infra/01`) → 4 (ingesta) → 5 (`infra/02`) → 6 (reporte y tablero).

---

## Paso 0. Preparar el proyecto (una sola vez, en la consola web)

1. Entra a <https://console.cloud.google.com> con tu cuenta de Google.
2. **Crea un proyecto:** en la barra superior, abre el selector de proyectos y elige
   **Proyecto nuevo**. Ponle un nombre, por ejemplo `capstone-bigdata`.
3. **Anota el ID del proyecto.** No es el nombre: es el identificador que aparece debajo
   del nombre, por ejemplo `capstone-bigdata-471203`. Lo usarás en todos los comandos.
4. **Vincula la facturación:** menú ☰ › **Facturación** › vincula una cuenta de facturación
   (la de tus créditos de estudiante o de prueba). Sin esto no se pueden crear máquinas.
5. Tu usuario debe ser **Propietario (Owner)** del proyecto. Si tú lo creaste, ya lo eres.

> **Cuota de CPUs:** los proyectos nuevos suelen tener un límite global de 12 vCPU
> (`CPUS_ALL_REGIONS`). El pipeline ya viene configurado para caber en ese límite (perfil
> `cuota12`). Si tu límite es menor, revisa [Cuota de CPUs](#cuota-de-cpus).

---

## Paso 1. Abrir Cloud Shell y subir el proyecto

1. En la consola, haz clic en el ícono **`>_` Activar Cloud Shell** (arriba a la derecha).
   Se abre una terminal en la parte de abajo. La primera vez tarda unos segundos.
2. **Sube el zip:** en la barra de la terminal, abre el menú **⋮ (Más)** › **Subir**.
   Presiona **Elegir archivos**, selecciona `pulsored_pipeline.zip` y luego presiona el
   botón azul **Subir** del cuadro. Si solo eliges el archivo y cierras el cuadro, no se
   sube. Espera el aviso de "completado" abajo a la derecha y confirma con `ls`.
   Si la subida falla, usa **Abrir editor** y arrastra el zip al panel de archivos, o
   prueba con Google Chrome.
3. Descomprímelo y entra a la carpeta:

   ```bash
   unzip pulsored_pipeline.zip
   cd pulsored
   ls
   ```

   Debes ver: `COMO_EMPEZAR.md  README.md  docs  infra  ingest  jobs  requirements-dev.txt  sql  tablero  tests  tools`.
4. **Dile a gcloud qué proyecto usar** (cambia el ID por el tuyo):

   ```bash
   export PROYECTO=capstone-bigdata-471203
   gcloud config set project $PROYECTO
   echo "export PROYECTO=$PROYECTO" >> ~/.bashrc
   ```

   La última línea hace que la variable se recuerde si Cloud Shell se reinicia. Si aparece
   una ventana **"Autorizar Cloud Shell"**, acepta.

> **Cómo pegar los comandos:** copia solo las líneas de adentro de cada recuadro. Los
> ` ``` ` y la palabra `bash` que aparece junto a ellos son formato de este documento, no
> comandos.
>
> **Cloud Shell se cierra tras un rato sin actividad**, pero tus archivos se conservan.
> Al volver, sigue la [rutina de reconexión](#rutina-de-reconexión).

---

## Paso 2. Crear la infraestructura: `infra/00`

En Cloud Shell, dentro de la carpeta `pulsored`:

```bash
bash infra/00_crear_infraestructura.sh
```

Tarda unos 5 minutos. Muestra 9 etapas (`==> 1/9 … 9/9`):

| Etapa | Qué hace |
|---|---|
| 1 | Activa las APIs de Dataproc, Compute Engine, Cloud Storage, Secret Manager e IAM |
| 2 | Prepara la red `default` y activa Private Google Access (Dataproc llega a Storage sin IP pública) |
| 3 | Revisa tu cuota de CPUs y avisa si no alcanza |
| 4 | Crea los 2 buckets |
| 5 | Crea la cuenta de servicio `pulsored-dataproc` con permisos mínimos |
| 6 | Genera la contraseña del pipeline y la guarda en Secret Manager (nunca en el código) |
| 7 | Crea la VM `pulsored-mariadb` (e2-medium, Debian 12), que instala MariaDB sola al arrancar |
| 8 | Abre los puertos: SSH, 3306 para Dataproc y 3306 para Data Studio (solo la IP de Google) |
| 9 | Descarga el driver JDBC de MariaDB y sube el código al bucket |

**Si algo falla**, lee el mensaje, corrígelo (consulta [Problemas frecuentes](#problemas-frecuentes))
y **vuelve a ejecutar el mismo comando**. El script omite lo que ya existe.

**Cómo comprobarlo:**

```bash
bash infra/verificar_estado.sh
```

Todo lo del "Paso 1 (infra/00)" debe salir `[OK]`. También puedes verlo en la consola:
menú ☰ › **Cloud Storage** › Buckets, y menú ☰ › **Compute Engine** › Instancias de VM.

---

## Paso 3. Configurar la base de datos: `infra/01`

Espera **unos 5 minutos** después del paso 2: la VM necesita ese tiempo para instalar
MariaDB. Luego, en Cloud Shell:

```bash
bash infra/01_configurar_mariadb.sh
```

- La primera vez, gcloud crea tus llaves SSH y pide una frase de contraseña: presiona
  **Enter** dos veces (sin frase).
- El script se copia solo a la VM y ahí:
  - activa SSL;
  - crea la base `pulsored` con 13 tablas y 6 vistas;
  - asigna las contraseñas;
  - carga los supuestos del modelo de ROI.
- Si responde "MariaDB aún no está instalada", espera 2 o 3 minutos y repítelo.

Al final imprime un recuadro con la **contraseña de `tablero_ro`**. **Cópiala y guárdala**:
la necesitarás solo si usas Data Studio. Si la pierdes, o si más adelante te sale
`Access denied`, ejecuta `bash infra/04_restablecer_acceso_tablero.sh`: genera una nueva y
comprueba el acceso.

> **Tip:** la primera vez que gcloud crea tu llave SSH pregunta una frase. Si le pusiste
> una, te la pedirá en cada comando que entre a la VM. Para teclearla una sola vez por
> sesión: `eval "$(ssh-agent -s)" && ssh-add ~/.ssh/google_compute_engine`.

---

## Paso 4. Descargar los datos (19.4 GB): ingesta

La descarga la hace **la VM**, no Cloud Shell. Cloud Shell solo tiene 5 GB de disco y se
desconecta si no lo usas. La VM descarga archivo por archivo desde Harvard Dataverse,
verifica el MD5 de cada uno, lo sube al bucket y borra la copia local.

Harvard Dataverse pide un registro de uso (*guestbook*) antes de cada descarga. Sin él,
responde con el error 400. Define tus datos reales antes de lanzar:

```bash
export DV_NOMBRE="Tu Nombre" DV_EMAIL="tu@correo.com" DV_INSTITUCION="Tu universidad"
bash ingest/lanzar_en_vm.sh iniciar
```

Si Dataverse pidiera una cuenta, crea una gratis en <https://dataverse.harvard.edu>. En tu
cuenta, entra a **API Token** y agrégalo con `export DATAVERSE_TOKEN=...` antes de `iniciar`.

Ya puedes cerrar Cloud Shell. El tiempo depende de la velocidad de Dataverse: puede ir de
decenas de minutos a un par de horas. Para consultar el avance cuando quieras:

```bash
bash ingest/lanzar_en_vm.sh estado
```

**Terminó bien** si las últimas líneas dicen:

```
Archivos de actividad: 62 (esperados 62) | Volumen: 19.xx GB (requisito >= 15 GB)
```

`bash infra/verificar_estado.sh` también debe mostrar `[OK] Archivos diarios: 62 de 62`.
El script es reanudable: si se interrumpe, vuelve a lanzarlo y solo descargará lo que falte.

**Si el log muestra un error 403 o de conexión con Dataverse**, significa que Dataverse
está bloqueando la IP de la nube. En ese caso, o si la descarga con guestbook sigue
fallando, usa el plan B:

1. En tu computadora, descarga los archivos desde el navegador.
   - Actividad: <https://doi.org/10.7910/DVN/EGZHFV> (62 archivos `sms-call-internet-mi-AAAA-MM-DD.txt`). Bájalos **uno por uno o por grupos**: el ZIP completo supera el límite de 15 GB de Dataverse.
   - Cuadrícula: <https://doi.org/10.7910/DVN/QJWLFU> (`milano-grid.geojson`).
2. En la consola: menú ☰ › **Cloud Storage** › bucket `TU-PROYECTO-pulsored-lake`.
   - Crea la carpeta `raw/telecom/` y arrastra ahí los 62 `.txt`.
   - Crea `raw/grid/` y arrastra el `.geojson`. Debe llamarse exactamente `milano-grid.geojson`.
3. Comprueba con `bash infra/verificar_estado.sh`.

---

## Paso 5. Ejecutar el pipeline: `infra/02`

En Cloud Shell:

```bash
bash infra/02_ejecutar_pipeline.sh
```

Usa el perfil `cuota12` (10 vCPU). Si tienes más cuota, puedes pedir un clúster más grande
con `PERFIL=estandar bash infra/02_ejecutar_pipeline.sh` (ver [Cuota de CPUs](#cuota-de-cpus)).
El script revisa tu cuota antes de crear nada.

El script hace lo siguiente:

1. Verifica que existan los datos y enciende la VM si estaba apagada.
2. Sube el código y registra el **Workflow Template**.
3. Dataproc **crea el clúster** y corre en cadena los 7 jobs:
   1. crudo a staging;
   2. quality gate;
   3. marts;
   4. segmentación;
   5. benchmark;
   6. reporte HTML;
   7. carga a MariaDB.
4. Dataproc **borra el clúster** al terminar, así que solo pagas mientras corre.

Sigue el avance en el enlace que imprime, o en menú ☰ › **Dataproc** › Flujos de trabajo o Trabajos.

- **Si Cloud Shell se desconecta, el pipeline sigue corriendo en GCP.** Al volver, consulta
  el estado en la consola y, cuando termine, trae el reporte con:
  `gcloud storage cp gs://$PROYECTO-pulsored-lake/reportes/* resultados/`
- **Si se detiene en el paso `calidad`**, el quality gate encontró un problema crítico. Esto es
  intencional: evita publicar datos malos. Abre ese trabajo en Dataproc › Trabajos: la tabla de
  controles dice cuál falló.

Con el perfil `cuota12`, la corrida completa suele tardar entre 45 minutos y 2 horas. El
tiempo real de cada job queda registrado. Para ver en qué job va, desde cualquier sesión:

```bash
gcloud dataproc jobs list --region=us-central1 --limit=7
```

**Prueba de escalabilidad (para la sección 4.k del documento):** repite la misma carga
con un clúster de 4 núcleos (perfil `cuota8`). También cabe en 12 vCPU:

```bash
bash infra/03_prueba_escalabilidad.sh
```

El reporte compara las dos corridas (`8cores` contra `4cores`). Si tu cuota es de 40 vCPU
o más, puedes medir escalamiento horizontal con
`PERFIL=estandar WORKERS=4 bash infra/03_prueba_escalabilidad.sh`.

---

## Paso 6. Ver resultados y armar el tablero

**Reporte ejecutivo (HTML):** en Cloud Shell,

```bash
cloudshell download resultados/reporte_pulsored.html
```

Ábrelo en tu navegador. Trae los KPIs, mapas, segmentos, eventos, ROI, calidad y rendimiento.

**Tablero interactivo listo (recomendado):** genera un tablero HTML con mapas, filtros por tipo
de zona, detalle de hotspots, simulador de ROI, eventos y calidad. Lee directamente la base MariaDB:

```bash
bash tablero/generar_tablero.sh
cloudshell download resultados/tablero_pulsored.html
```

Ábrelo **en un navegador** (Chrome, Safari o Firefox) y con internet, porque carga la
biblioteca de gráficas y el mapa base. Las vistas previas (la barra espaciadora del Finder,
Drive, el correo) no ejecutan las gráficas interactivas. También queda guardado en
`gs://TU-PROYECTO-pulsored-lake/reportes/`.

El tablero es una foto de los datos: no tiene contraseñas ni se conecta a la base. Para
compartirlo, manda el archivo o publícalo como enlace:

```bash
bash tablero/publicar_tablero.sh            # imprime el enlace; repetirlo actualiza el tablero
bash tablero/publicar_tablero.sh retirar    # deja de compartirlo
```

El enlace se publica en un bucket aparte, así que tus datos crudos nunca quedan públicos.

**Opcional: tablero en Data Studio (antes Looker Studio):**

1. Consigue la IP externa de la VM y su certificado:

   ```bash
   gcloud compute instances describe pulsored-mariadb --zone=us-central1-a \
     --format="get(networkInterfaces[0].accessConfigs[0].natIP)"
   gcloud compute scp pulsored-mariadb:/etc/mysql/ssl/server-cert.pem . --zone=us-central1-a
   cloudshell download server-cert.pem
   ```

2. Entra a <https://datastudio.google.com> › **Crear** › **Fuente de datos** › conector **MySQL**
   y llena **BÁSICO** así:

   | Campo | Valor |
   |---|---|
   | Host | la IP externa |
   | Puerto | 3306 |
   | Base de datos | `pulsored` |
   | Usuario | `tablero_ro` |
   | Contraseña | la del paso 3 |

   Marca **Habilitar SSL** y sube `server-cert.pem` como certificado del servidor.
3. Crea una fuente por cada vista: `v_kpi_ejecutivo`, `v_mapa_cuadrantes`, `v_hotspots`,
   `v_ahorro_por_segmento`, `v_ahorro_estimado`, y además la tabla `diario_ciudad`.
4. **Mapa:** en `v_mapa_cuadrantes`, agrega el campo calculado `CONCAT(lat, ",", lon)` y
   cambia su tipo a **Geo › Latitud, longitud**.
5. Distribuye las páginas como en `docs/maqueta_tablero.png`.

Si Data Studio responde "Access denied" o no conecta, ejecuta
`bash infra/04_restablecer_acceso_tablero.sh` y usa la contraseña nueva que imprime.

Data Studio documenta oficialmente MySQL 8.0 y 9.0. MariaDB usa el mismo protocolo y
normalmente conecta, pero si no lo logras, el reporte HTML cubre el requisito de
visualización.

**Cifras para el documento técnico:**

```bash
gcloud compute ssh pulsored-mariadb --zone=us-central1-a \
  --command="sudo mariadb < ~/pulsored_setup/sql/03_kpis_documento.sql" > resultados/kpis_documento.txt
cloudshell download resultados/kpis_documento.txt
```

---

## Cuota de CPUs

El paso 2 imprime tus límites. El que suele frenar a los proyectos nuevos es
`CPUS_ALL_REGIONS`: el total de vCPU encendidas a la vez en todo el proyecto, casi siempre
12. La VM de MariaDB ocupa 2 de ellas. Por eso el pipeline tiene tres perfiles:

| `PERFIL` | Máquinas del clúster | Núcleos de trabajo | vCPU con la VM | Etiqueta de la corrida |
|---|---|---|---|---|
| `cuota12` (predeterminado) | 1× n2-standard-2 + 2× n2-standard-4 | 8 | 12 | `8cores` |
| `cuota8` | 1× n2-standard-2 + 2× n2-standard-2 | 4 | 8 | `4cores` |
| `estandar` | 1× n2-standard-4 + 2× n2-standard-8 | 16 | 22 | `16cores` |

Se elige al ejecutar, por ejemplo `PERFIL=cuota8 bash infra/02_ejecutar_pipeline.sh`. No
hay que editar ningún archivo. Con más cuota puedes usar `estandar`, y agregar `WORKERS=4`
para escalar horizontalmente.

**Para pedir más cuota:** menú ☰ › **IAM y administración** › **Cuotas y límites del
sistema**. Busca **CPUs (all regions)**, elige **Editar** y pide 40. En cuentas nuevas puede
tardar o ser rechazado; el perfil `cuota12` no depende de eso.

---

## Problemas frecuentes

| Mensaje o síntoma | Solución |
|---|---|
| `billing account ... not found` / `requires billing` | Vincula la facturación (paso 0.4) |
| `Quota 'CPUS' exceeded`, `N2_CPUS` o `CPUS_ALL_REGIONS` | Usa un perfil más chico (ver [Cuota de CPUs](#cuota-de-cpus)) |
| La ingesta falla con `HTTP 400` | Harvard Dataverse exige el registro de uso: define `DV_NOMBRE`, `DV_EMAIL` y `DV_INSTITUCION` antes de `iniciar` (paso 4) |
| La ingesta muestra `Dataverse rechazo la descarga con guestbook` | Lee el mensaje del servidor. Si pide autenticación, crea una cuenta en dataverse.harvard.edu y exporta `DATAVERSE_TOKEN` |
| `Access denied for user 'tablero_ro'` | `bash infra/04_restablecer_acceso_tablero.sh` (contraseña nueva y revisión de SSL) |
| El tablero abre pero las gráficas no aparecen | Ábrelo en un navegador con internet, no en una vista previa |
| `unzip: cannot find ... .zip` | El zip no se subió: repite la subida presionando el botón azul **Subir** y confirma con `ls ~` |
| `PROYECTO: Primero: export PROYECTO=...` | Cloud Shell se reinició: ejecuta `export PROYECTO=tu-id` y `cd pulsored` |
| `No such file or directory: infra/...` | No estás en la carpeta: `cd ~/pulsored` |
| `does not have iam.serviceAccounts.actAs` al crear el clúster | Ejecuta el comando de abajo y reintenta el paso 5 |
| `MariaDB aún no está instalada` | Espera 2-3 minutos; para ver el avance de la VM: `gcloud compute instances get-serial-port-output pulsored-mariadb --zone=us-central1-a \| tail -20` |
| El SSH se queda colgado o falla | Espera a que la VM termine de arrancar; confirma que existe la regla `pulsored-ssh` (menú ☰ › Red de VPC › Firewall) |
| El workflow falla en `calidad` | Revisa la salida de ese trabajo: la tabla indica el control que falló |
| El workflow falla en `carga-mariadb` | Confirma que el paso 3 terminó bien y que la VM está encendida; los demás resultados ya quedaron en el bucket |
| El nombre del bucket "ya está en uso" | Otro proyecto lo tiene: el nombre usa tu ID de proyecto, verifica que `PROYECTO` sea el correcto |

Comando para el error `actAs` (da al agente de Dataproc permiso de usar la cuenta de
servicio del proyecto):

```bash
NUM=$(gcloud projects describe $PROYECTO --format="value(projectNumber)")
gcloud iam service-accounts add-iam-policy-binding \
  pulsored-dataproc@$PROYECTO.iam.gserviceaccount.com \
  --member="serviceAccount:service-$NUM@dataproc-accounts.iam.gserviceaccount.com" \
  --role=roles/iam.serviceAccountUser
```

---

## Rutina de reconexión

Cada vez que abras una sesión nueva de Cloud Shell:

```bash
cd ~/pulsored
export PROYECTO=tu-id-de-proyecto
gcloud config set project $PROYECTO
eval "$(ssh-agent -s)" && ssh-add ~/.ssh/google_compute_engine
bash infra/verificar_estado.sh
```

`verificar_estado.sh` te dice en qué paso vas.

---

## Costos y cómo no gastar de más

- El **clúster** existe solo mientras corre el pipeline y se borra solo.
- La **VM** (e2-medium) cobra mientras está encendida. Apágala cuando no la uses; `infra/02`
  la vuelve a encender sola:

  ```bash
  gcloud compute instances stop pulsored-mariadb --zone=us-central1-a
  ```

- El **almacenamiento** (unas decenas de GB) cuesta poco al mes.
- Al terminar el curso, borra todo:

  ```bash
  gcloud compute instances delete pulsored-mariadb --zone=us-central1-a
  gcloud storage rm -r gs://$PROYECTO-pulsored-lake gs://$PROYECTO-pulsored-code
  gcloud storage rm -r gs://$PROYECTO-pulsored-publico   # si publicaste el tablero
  ```

Precios de referencia en `us-central1` (valídalos en la calculadora de Google Cloud):
n2-standard-2 cuesta alrededor de 0.10 USD/h, n2-standard-4 alrededor de 0.19 USD/h y
n2-standard-8 alrededor de 0.39 USD/h. Dataproc agrega 0.01 USD por vCPU-hora. Con el
perfil `cuota12` son unos 0.6 USD por hora de ejecución, y con `estandar` poco más de
1 USD por hora.

---

## Anexo: probar el código sin GCP (opcional)

Con Python 3.10 o superior y Java 17 en tu computadora:

```bash
pip install -r requirements-dev.txt
python tools/generar_muestra_sintetica.py --salida /tmp/lake   # datos SINTÉTICOS de prueba
export PYTHONPATH=jobs
python jobs/01_raw_a_staging.py --base /tmp/lake
python jobs/02_calidad.py --base /tmp/lake
python jobs/03_marts.py --base /tmp/lake --tipico-inicio 2013-11-04 --tipico-fin 2013-11-17
python jobs/04_segmentacion.py --base /tmp/lake --k-min 2 --k-max 5
python jobs/05_benchmark.py --base /tmp/lake --dia 2013-11-10 --cuadrante 5
python jobs/06_reporte_visual.py --base /tmp/lake
pytest -q tests/
```
