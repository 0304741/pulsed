"""Pruebas unitarias de las reglas de limpieza y de los calculos de negocio.
Ejecutar: PYTHONPATH=jobs pytest -q tests/"""
import importlib.util
import pathlib

import pytest
from pyspark.sql import Row, SparkSession
from pyspark.sql import types as T

RAIZ = pathlib.Path(__file__).resolve().parents[1] / "jobs"


def cargar(nombre):
    spec = importlib.util.spec_from_file_location(nombre, RAIZ / f"{nombre}.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


j01, j03 = cargar("01_raw_a_staging"), cargar("03_marts")
ESQUEMA = T.StructType(j01.ESQUEMA_RAW.fields + [T.StructField("archivo", T.StringType())])


@pytest.fixture(scope="session")
def spark():
    s = (SparkSession.builder.master("local[1]").appName("tests")
         .config("spark.sql.session.timeZone", "UTC")
         .config("spark.sql.shuffle.partitions", "2").getOrCreate())
    yield s
    s.stop()


def fila(sq, ms, cc, si=None, so=None, ci=None, co=None, net=None, corrupta=None,
         archivo="sms-call-internet-mi-2013-11-01.txt"):
    return (sq, ms, cc, si, so, ci, co, net, corrupta, archivo)


def crudo(spark, filas):
    return spark.createDataFrame(filas, ESQUEMA)


T0 = 1383260400000  # 2013-10-31 23:00 UTC = 2013-11-01 00:00 en Milan (CET)


def test_regla_valida_rechaza_defectos(spark):
    df = crudo(spark, [
        fila(1, T0, 39, 1.0, 1.0, 1.0, 1.0, 1.0),          # valida
        fila(10001, T0, 39, 1.0, 1.0, 1.0, 1.0, 1.0),      # fuera de rango
        fila(2, T0, 39, -1.0, 1.0, 1.0, 1.0, 1.0),         # negativo
        fila(None, None, None, corrupta="basura"),         # corrupta
    ])
    assert df.filter(j01.regla_valida()).count() == 1


def test_limpiar_desduplica_y_consolida(spark):
    df = crudo(spark, [
        fila(8, T0, 39, 1.0, 1.0, 1.0, 1.0, 2.0),
        fila(8, T0, 39, 1.0, 1.0, 1.0, 1.0, 2.0),          # duplicado exacto
        fila(8, T0, 0, net=0.5),                           # parcial: solo internet
        fila(8, T0, 0, si=0.2),                            # parcial: solo sms
    ])
    out = {r["country_code"]: r for r in j01.limpiar(df).collect()}
    assert len(out) == 2
    assert out[39]["internet"] == 2.0                      # no se duplica
    assert out[0]["internet"] == 0.5 and out[0]["sms_in"] == 0.2


def test_conversion_horaria_y_calendario(spark):
    stg = j01.limpiar(crudo(spark, [fila(1, T0, 39, 1.0, 1.0, 1.0, 1.0, 1.0)]))
    r = j01.consolidar_celda(stg).first()
    assert str(r["ts_local"]) == "2013-11-01 00:00:00"
    assert str(r["dt"]) == "2013-11-01"
    assert r["dow"] == 5 and r["slot"] == 0 and r["es_festivo"] is True  # viernes festivo


def test_ventanas_de_ahorro_agrupa_horas_consecutivas(spark):
    # Un cuadrante con 0-5 h de muy bajo trafico todos los dias: 7 ventanas de 6 h
    perfil = spark.createDataFrame([
        Row(square_id=1, dow=d, hora=h, internet_media=1.0 if h < 6 else 100.0,
            internet_p95=1.0 if h < 6 else 100.0, voz_media=0.1 if h < 6 else 10.0,
            voz_p95=0.1 if h < 6 else 10.0, sms_media=1.0, n_dias=7)
        for d in range(1, 8) for h in range(24)])
    presion = j03.presion_capacidad(perfil)
    islas, resumen = j03.ventanas_ahorro(perfil, presion)
    assert islas.count() == 7
    assert set(r["duracion_h"] for r in islas.collect()) == {6}
    assert resumen.first()["horas_elegibles_semana"] == 42


def test_cuadricula_detecta_identificador_y_centroide(spark, tmp_path):
    import json
    j02 = cargar("02_calidad")
    anillo = [[9.0, 45.4], [9.002, 45.4], [9.002, 45.402], [9.0, 45.402], [9.0, 45.4]]
    for campo in ("cellId", "id"):
        ruta = tmp_path / f"grid_{campo}.geojson"
        ruta.write_text(json.dumps({"type": "FeatureCollection", "features": [
            {"type": "Feature", "properties": {campo: 1},
             "geometry": {"type": "Polygon", "coordinates": [anillo]}}]}))
        r = j02.construir_dim_cuadricula(spark, str(ruta)).first()
        assert r["square_id"] == 1
        assert abs(r["lon"] - 9.001) < 1e-9 and abs(r["lat"] - 45.401) < 1e-9
