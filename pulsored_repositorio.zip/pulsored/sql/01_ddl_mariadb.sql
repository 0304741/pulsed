-- PulsoRed | Capa de servicio en MariaDB (10.6+)
-- Solo recibe marts agregados (cientos de miles de filas), nunca el detalle de 19 GB.
-- Sin FOREIGN KEY declaradas: la integridad referencial se valida en el quality gate
-- (job 02) y con 03_kpis_documento.sql (Q0); asi la recarga idempotente por TRUNCATE
-- no queda bloqueada por dependencias entre tablas.

CREATE DATABASE IF NOT EXISTS pulsored CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pulsored;

CREATE TABLE IF NOT EXISTS cuadrante (
  square_id              INT          NOT NULL PRIMARY KEY,
  lat                    DOUBLE       NOT NULL,
  lon                    DOUBLE       NOT NULL,
  cluster                INT          NOT NULL DEFAULT -1,   -- -1 = sin actividad
  hora_pico              TINYINT,
  trafico_hora_pico      DOUBLE,
  trafico_hora_pico_p95  DOUBLE,
  voz_hora_pico          DOUBLE,
  trafico_medio          DOUBLE,
  ratio_pico_medio       DOUBLE,
  indice_presion         DECIMAL(4,1),                        -- percentil 0-100
  es_hotspot             BOOLEAN,
  horas_elegibles_semana INT,
  n_ventanas             INT,
  pct_semana_elegible    DECIMAL(5,4),
  KEY ix_cluster (cluster),
  KEY ix_presion (indice_presion)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS perfil_semanal (
  square_id      INT     NOT NULL,
  dow            TINYINT NOT NULL,     -- 1 = lunes ... 7 = domingo
  hora           TINYINT NOT NULL,
  internet_media DOUBLE, internet_p95 DOUBLE,
  voz_media      DOUBLE, voz_p95      DOUBLE,
  sms_media      DOUBLE,
  n_dias         INT,
  PRIMARY KEY (square_id, dow, hora)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ventana_ahorro (
  square_id   INT     NOT NULL,
  inicio_how  INT     NOT NULL,        -- hora de la semana 0-167
  duracion_h  INT     NOT NULL,
  dia_inicio  TINYINT NOT NULL,
  hora_inicio TINYINT NOT NULL,
  PRIMARY KEY (square_id, inicio_how)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS anomalia (
  square_id  INT     NOT NULL,
  dt         DATE    NOT NULL,
  hora       TINYINT NOT NULL,
  dow        TINYINT, es_festivo BOOLEAN,
  internet   DOUBLE, mediana DOUBLE, z DOUBLE, exceso_pct DOUBLE,
  PRIMARY KEY (square_id, dt, hora),
  KEY ix_fecha (dt, hora)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS evento_ciudad (
  dt                  DATE    NOT NULL,
  hora                TINYINT NOT NULL,
  cuadrantes_anomalos INT, exceso_total DOUBLE, z_max DOUBLE,
  PRIMARY KEY (dt, hora)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS diario_ciudad (
  dt DATE NOT NULL PRIMARY KEY,
  dow TINYINT, es_festivo BOOLEAN,
  internet DOUBLE, voz DOUBLE, sms DOUBLE, voz_sms_intl DOUBLE,
  pct_internacional DECIMAL(6,4)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS cluster_perfil (
  cluster INT NOT NULL, tipo_dia VARCHAR(3) NOT NULL, hora TINYINT NOT NULL,
  valor_norm DOUBLE,
  PRIMARY KEY (cluster, tipo_dia, hora)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS cluster_resumen (
  cluster INT NOT NULL PRIMARY KEY,
  n_cuadrantes INT, ratio_fds_lab DOUBLE, pct_nocturno DOUBLE,
  etiqueta_sugerida VARCHAR(60)
) ENGINE=InnoDB;

-- Mantenida por el equipo de analitica (no la toca el pipeline)
CREATE TABLE IF NOT EXISTS cluster_etiqueta (
  cluster INT NOT NULL PRIMARY KEY,
  etiqueta_final VARCHAR(60) NOT NULL,
  validado_por VARCHAR(60), validado_en DATE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS seleccion_k (
  k INT NOT NULL PRIMARY KEY, silhouette DOUBLE
) ENGINE=InnoDB;

-- Historico de calidad: se ANEXA en cada corrida (trazabilidad)
CREATE TABLE IF NOT EXISTS dq_resultado (
  evaluado_en DATETIME(6) NOT NULL,
  control     VARCHAR(60) NOT NULL,
  valor DOUBLE, umbral DOUBLE,
  estado      VARCHAR(10) NOT NULL,    -- OK / ALERTA / FALLA
  severidad   VARCHAR(10) NOT NULL,    -- critica / alerta
  PRIMARY KEY (evaluado_en, control)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS dq_por_dia (
  dt DATE NOT NULL PRIMARY KEY,
  slots INT, cuadrantes INT,
  cobertura_temporal DOUBLE, cobertura_espacial DOUBLE
) ENGINE=InnoDB;

-- Supuestos del modelo de ROI: los captura Finanzas/Red, no el pipeline
CREATE TABLE IF NOT EXISTS param_roi (
  parametro VARCHAR(40) NOT NULL PRIMARY KEY,
  valor     DOUBLE      NOT NULL,
  unidad    VARCHAR(30),
  fuente    VARCHAR(120)
) ENGINE=InnoDB;

-- Usuario del pipeline (TRUNCATE requiere el privilegio DROP en MariaDB)
CREATE USER IF NOT EXISTS 'pipeline_rw'@'%' IDENTIFIED BY 'CAMBIAR_EN_SECRET_MANAGER';
GRANT SELECT, INSERT, UPDATE, DELETE, DROP ON pulsored.* TO 'pipeline_rw'@'%';

-- Usuario de solo lectura para el tablero
CREATE USER IF NOT EXISTS 'tablero_ro'@'%' IDENTIFIED BY 'CAMBIAR_EN_SECRET_MANAGER' REQUIRE SSL;
GRANT SELECT ON pulsored.* TO 'tablero_ro'@'%';
