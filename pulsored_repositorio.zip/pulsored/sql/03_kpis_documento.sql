-- PulsoRed | Consultas que producen cada cifra del documento (seccion 5)
-- Cada bloque Qn corresponde a un campo [Qn] marcado en el informe.
USE pulsored;

-- Q0. Integridad relacional post-carga (todas deben devolver 0)
SELECT 'perfil_sin_cuadrante' AS control, COUNT(*) AS huerfanos
FROM perfil_semanal p LEFT JOIN cuadrante c USING (square_id) WHERE c.square_id IS NULL
UNION ALL
SELECT 'ventana_sin_cuadrante', COUNT(*)
FROM ventana_ahorro v LEFT JOIN cuadrante c USING (square_id) WHERE c.square_id IS NULL
UNION ALL
SELECT 'anomalia_sin_cuadrante', COUNT(*)
FROM anomalia a LEFT JOIN cuadrante c USING (square_id) WHERE c.square_id IS NULL
UNION ALL
SELECT 'cuadrante_cluster_inexistente', COUNT(*)
FROM cuadrante c LEFT JOIN cluster_resumen r USING (cluster)
WHERE c.cluster >= 0 AND r.cluster IS NULL;

-- Q1. Concentracion: participacion de los hotspots en el trafico de hora pico
SELECT SUM(es_hotspot) AS hotspots,
       ROUND(100 * SUM(CASE WHEN es_hotspot THEN trafico_hora_pico END)
             / SUM(trafico_hora_pico), 1) AS pct_trafico_pico
FROM cuadrante;

-- Q2. Hora pico mas frecuente de la ciudad (dia laboral)
SELECT hora_pico, COUNT(*) AS cuadrantes
FROM cuadrante WHERE cluster >= 0
GROUP BY hora_pico ORDER BY cuadrantes DESC LIMIT 3;

-- Q3. Relacion pico / medio (dimensionamiento): mediana y p90
SELECT DISTINCT
  MEDIAN(ratio_pico_medio) OVER ()                                      AS mediana,
  PERCENTILE_CONT(0.9) WITHIN GROUP (ORDER BY ratio_pico_medio) OVER () AS p90
FROM cuadrante WHERE cluster >= 0;

-- Q4. Ventanas de ahorro: promedio, mediana y % de cuadrantes con >= 2 h diarias
SELECT DISTINCT
  ROUND(AVG(horas_elegibles_semana) OVER (), 1)                         AS promedio_h_semana,
  MEDIAN(horas_elegibles_semana) OVER ()                                AS mediana_h_semana,
  ROUND(100 * AVG(horas_elegibles_semana >= 14) OVER (), 1)             AS pct_cuadrantes_2h_dia
FROM cuadrante WHERE cluster >= 0;

-- Q5. Segmentos: tamano, presion y ahorro
SELECT * FROM v_ahorro_por_segmento ORDER BY cuadrantes DESC;

-- Q6. Diez horas-evento con mas cuadrantes anomalos
SELECT dt, hora, cuadrantes_anomalos, ROUND(z_max, 1) AS z_max
FROM evento_ciudad ORDER BY cuadrantes_anomalos DESC, z_max DESC LIMIT 10;

-- Q7. Efecto de temporada: trafico diario promedio navidad vs periodo tipico
SELECT CASE WHEN dt BETWEEN '2013-12-23' AND '2014-01-01' THEN 'navidad'
            WHEN dt BETWEEN '2013-11-04' AND '2013-12-22' AND NOT es_festivo THEN 'tipico'
            ELSE 'otro' END AS periodo,
       ROUND(AVG(internet)) AS internet_diario_prom,
       ROUND(AVG(voz))      AS voz_diaria_prom
FROM diario_ciudad GROUP BY periodo;

-- Q8. Laboral vs fin de semana (periodo tipico)
SELECT CASE WHEN dow <= 5 THEN 'laboral' ELSE 'fin_de_semana' END AS tipo_dia,
       ROUND(AVG(internet)) AS internet_diario_prom,
       ROUND(AVG(pct_internacional) * 100, 2) AS pct_internacional
FROM diario_ciudad
WHERE dt BETWEEN '2013-11-04' AND '2013-12-22' AND NOT es_festivo
GROUP BY tipo_dia;

-- Q9. Resultado del ultimo quality gate
SELECT control, ROUND(valor, 4) AS valor, umbral, estado, severidad
FROM dq_resultado WHERE evaluado_en = (SELECT MAX(evaluado_en) FROM dq_resultado)
ORDER BY severidad, control;

-- Q10. Modelo de ROI con los supuestos vigentes en param_roi
SELECT * FROM v_ahorro_estimado;
