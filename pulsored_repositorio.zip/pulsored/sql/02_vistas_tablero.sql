-- PulsoRed | Vistas que alimentan el tablero (Looker Studio via conector MySQL)
USE pulsored;

CREATE OR REPLACE VIEW v_cluster AS
SELECT r.cluster, r.n_cuadrantes, r.ratio_fds_lab, r.pct_nocturno,
       COALESCE(e.etiqueta_final, r.etiqueta_sugerida) AS etiqueta,
       e.etiqueta_final IS NOT NULL                     AS etiqueta_validada
FROM cluster_resumen r
LEFT JOIN cluster_etiqueta e ON e.cluster = r.cluster;

CREATE OR REPLACE VIEW v_mapa_cuadrantes AS
SELECT c.square_id, c.lat, c.lon, c.cluster, COALESCE(v.etiqueta, 'Sin actividad') AS segmento,
       c.hora_pico, c.trafico_hora_pico, c.indice_presion, c.es_hotspot,
       c.horas_elegibles_semana, c.pct_semana_elegible
FROM cuadrante c
LEFT JOIN v_cluster v ON v.cluster = c.cluster;

CREATE OR REPLACE VIEW v_hotspots AS
SELECT square_id, lat, lon, segmento, hora_pico, trafico_hora_pico, indice_presion
FROM v_mapa_cuadrantes
WHERE es_hotspot
ORDER BY indice_presion DESC;

CREATE OR REPLACE VIEW v_ahorro_por_segmento AS
SELECT segmento,
       COUNT(*)                             AS cuadrantes,
       ROUND(AVG(horas_elegibles_semana),1) AS horas_elegibles_prom,
       SUM(horas_elegibles_semana >= 14)    AS cuadrantes_2h_diarias_o_mas,
       ROUND(AVG(indice_presion),1)         AS presion_prom
FROM v_mapa_cuadrantes
WHERE cluster >= 0
GROUP BY segmento;

CREATE OR REPLACE VIEW v_ahorro_estimado AS
WITH h AS (
  SELECT AVG(horas_elegibles_semana) AS horas_semana
  FROM cuadrante WHERE cluster >= 0
), p AS (
  SELECT MAX(CASE WHEN parametro = 'n_sitios'           THEN valor END) AS n_sitios,
         MAX(CASE WHEN parametro = 'kw_capa_apagable'   THEN valor END) AS kw,
         MAX(CASE WHEN parametro = 'tarifa_kwh'         THEN valor END) AS tarifa,
         MAX(CASE WHEN parametro = 'factor_realizacion' THEN valor END) AS realizacion,
         MAX(CASE WHEN parametro = 'costo_anual_plataforma' THEN valor END) AS costo
  FROM param_roi
)
SELECT ROUND(h.horas_semana, 1)                                              AS horas_elegibles_semana_prom,
       ROUND(p.n_sitios * p.kw * h.horas_semana * 52 * p.realizacion)       AS kwh_ahorrados_anio,
       ROUND(p.n_sitios * p.kw * h.horas_semana * 52 * p.realizacion * p.tarifa) AS ahorro_anual,
       p.costo                                                               AS costo_anual_plataforma,
       ROUND((p.n_sitios * p.kw * h.horas_semana * 52 * p.realizacion * p.tarifa - p.costo)
             / NULLIF(p.costo, 0), 1)                                        AS roi_veces
FROM h CROSS JOIN p;

CREATE OR REPLACE VIEW v_kpi_ejecutivo AS
SELECT
  (SELECT COUNT(*) FROM cuadrante WHERE cluster >= 0)                AS cuadrantes_activos,
  (SELECT COUNT(*) FROM cuadrante WHERE es_hotspot)                  AS hotspots,
  (SELECT ROUND(100 * SUM(CASE WHEN es_hotspot THEN trafico_hora_pico ELSE 0 END)
                / SUM(trafico_hora_pico), 1) FROM cuadrante)         AS pct_trafico_pico_en_hotspots,
  (SELECT horas_elegibles_semana_prom FROM v_ahorro_estimado)        AS horas_ahorro_semana_prom,
  (SELECT ahorro_anual FROM v_ahorro_estimado)                       AS ahorro_anual_estimado,
  (SELECT COUNT(*) FROM evento_ciudad WHERE cuadrantes_anomalos >= 5) AS eventos_detectados,
  (SELECT CASE WHEN SUM(estado = 'FALLA') > 0 THEN 'FALLA'
               WHEN SUM(estado = 'ALERTA') > 0 THEN 'CON ALERTAS' ELSE 'OK' END
   FROM dq_resultado
   WHERE evaluado_en = (SELECT MAX(evaluado_en) FROM dq_resultado))  AS estado_calidad;
