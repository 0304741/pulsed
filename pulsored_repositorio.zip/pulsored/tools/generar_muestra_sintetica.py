"""Genera una muestra SINTETICA con el mismo formato que el dataset de Milan.

Uso exclusivo para pruebas locales y CI del pipeline: los valores no representan
trafico real. Inyecta defectos conocidos (duplicados, fila corrupta, negativo,
cuadrante fuera de rango, filas parciales) y un evento para validar cada control.
"""
import argparse
import json
import os
import random
from datetime import datetime, timedelta, timezone

CET = timezone(timedelta(hours=1))  # noviembre-diciembre: Milan en horario CET (UTC+1)


def perfil(tipo, hora, fin_semana):
    if tipo == "oficina":
        base = 1.0 if 8 <= hora <= 19 else 0.08
        return base * (0.35 if fin_semana else 1.0)
    if tipo == "nocturno":
        base = 1.0 if (hora >= 20 or hora <= 2) else 0.25
        return base * (1.3 if fin_semana else 1.0)
    return 0.12 if hora <= 6 else (0.6 if hora < 18 else 1.0)  # residencial


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--salida", required=True)
    p.add_argument("--cuadrantes", type=int, default=100)
    p.add_argument("--dias", type=int, default=20)
    a = p.parse_args()
    random.seed(7)
    raw = os.path.join(a.salida, "raw", "telecom")
    grid = os.path.join(a.salida, "raw", "grid")
    os.makedirs(raw, exist_ok=True)
    os.makedirs(grid, exist_ok=True)

    tipos = {sq: random.choice(["oficina", "residencial", "nocturno"]) for sq in range(1, a.cuadrantes + 1)}
    escala = {sq: random.lognormvariate(3, 0.8) for sq in tipos}
    evento_dia, evento_sq = 12, set(range(1, 6))  # "concierto": dia 12, 20-23 h, cuadrantes 1-5

    inicio = datetime(2013, 11, 1, tzinfo=CET)
    for d in range(a.dias):
        dia = inicio + timedelta(days=d)
        lineas = []
        for slot in range(144):
            t = dia + timedelta(minutes=10 * slot)
            ms = int(t.timestamp() * 1000)
            fds = t.weekday() >= 5
            for sq in tipos:
                f = perfil(tipos[sq], t.hour, fds) * escala[sq] * random.uniform(0.85, 1.15)
                if d == evento_dia and sq in evento_sq and 20 <= t.hour <= 23:
                    f *= 6
                sms_i, sms_o, call_i, call_o = (round(f * k, 4) for k in (0.3, 0.25, 0.2, 0.2))
                lineas.append(f"{sq}\t{ms}\t39\t{sms_i}\t{sms_o}\t{call_i}\t{call_o}\t{round(f * 3, 4)}")
                if random.random() < 0.3:  # actividad internacional sin internet
                    lineas.append(f"{sq}\t{ms}\t{random.choice([33, 49, 86])}\t{round(f * .02, 4)}\t\t{round(f * .01, 4)}\t\t")
        # defectos inyectados
        lineas.append(lineas[5])                                   # duplicado exacto
        lineas.append("esto\tno\tes\tuna\tfila")                   # corrupta
        lineas.append(f"10001\t{ms}\t39\t1\t1\t1\t1\t1")           # fuera de rango
        lineas.append(f"7\t{ms}\t39\t-3\t1\t1\t1\t1")              # negativo
        lineas.append(f"8\t{ms}\t0\t\t\t\t\t0.5")                  # parcial (solo internet)...
        lineas.append(f"8\t{ms}\t0\t0.2\t\t\t\t")                  # ...y su complemento
        with open(os.path.join(raw, f"sms-call-internet-mi-{dia:%Y-%m-%d}.txt"), "w") as fh:
            fh.write("\n".join(lineas) + "\n")

    lado = int(a.cuadrantes ** 0.5)
    feats = []
    for sq in tipos:
        i, j = (sq - 1) // lado, (sq - 1) % lado
        x0, y0, s = 9.0 + j * 0.003, 45.35 + i * 0.002, 0.003
        anillo = [[x0, y0], [x0 + s, y0], [x0 + s, y0 + .002], [x0, y0 + .002], [x0, y0]]
        feats.append({"type": "Feature", "properties": {"cellId": sq},
                      "geometry": {"type": "Polygon", "coordinates": [anillo]}})
    with open(os.path.join(grid, "milano-grid.geojson"), "w") as fh:
        json.dump({"type": "FeatureCollection", "features": feats}, fh)
    print(f"muestra sintetica en {a.salida}: {a.cuadrantes} cuadrantes x {a.dias} dias")


if __name__ == "__main__":
    main()
