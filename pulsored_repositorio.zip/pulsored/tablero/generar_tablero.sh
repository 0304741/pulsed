#!/usr/bin/env bash
# PulsoRed | Genera el tablero ejecutivo interactivo leyendo MariaDB y te lo deja listo para bajar.
# Se ejecuta en CLOUD SHELL (raiz del repositorio):  bash tablero/generar_tablero.sh
set -euo pipefail
cd "$(dirname "$0")/.."
PROYECTO="${PROYECTO:?Primero: export PROYECTO=tu-id-de-proyecto}"
ZONA="us-central1-a"
gcloud compute ssh pulsored-mariadb --zone="$ZONA" --command="mkdir -p ~/pulsored_setup/tablero"
gcloud compute scp tablero/generar_tablero.py tablero/plantilla_tablero.html \
  pulsored-mariadb:~/pulsored_setup/tablero/ --zone="$ZONA"
gcloud compute ssh pulsored-mariadb --zone="$ZONA" --command="(command -v python3 >/dev/null || sudo apt-get install -y -qq python3) && \
  cd ~/pulsored_setup/tablero && sudo python3 generar_tablero.py plantilla_tablero.html /tmp/tablero_pulsored.html && \
  sudo chmod 644 /tmp/tablero_pulsored.html"
mkdir -p resultados
gcloud compute scp pulsored-mariadb:/tmp/tablero_pulsored.html resultados/ --zone="$ZONA"
gcloud storage cp resultados/tablero_pulsored.html "gs://${PROYECTO}-pulsored-lake/reportes/" --quiet
echo "Listo. Para bajarlo a tu computadora:  cloudshell download resultados/tablero_pulsored.html"
