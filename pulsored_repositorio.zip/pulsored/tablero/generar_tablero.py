#!/usr/bin/env python3
"""PulsoRed | Genera el tablero ejecutivo interactivo (un solo HTML) desde la capa de
servicio MariaDB. Solo usa la biblioteca estandar de Python y el cliente `mariadb`, asi que
corre tal cual dentro de la VM pulsored-mariadb (lo lanza tablero/generar_tablero.sh).

Uso: sudo python3 generar_tablero.py plantilla_tablero.html /tmp/tablero_pulsored.html
"""
import csv
import datetime
import io
import json
import math
import subprocess
import sys
from collections import defaultdict


def valor(v):
    if v == "NULL":
        return None
    try:
        return int(v)
    except ValueError:
        pass
    try:
        f = float(v)
        return None if math.isnan(f) or math.isinf(f) else round(f, 4)
    except ValueError:
        return v


def consulta(sql):
    r = subprocess.run(["mariadb", "--batch", "pulsored", "-e", sql], capture_output=True, text=True)
    if r.returncode != 0:
        sys.exit(f"Error en MariaDB: {r.stderr.strip()}\nSQL: {sql}")
    filas = list(csv.reader(io.StringIO(r.stdout), delimiter="\t", quoting=csv.QUOTE_NONE))
    if not filas:
        return [], []
    return filas[0], [[valor(v) for v in f] for f in filas[1:]]


def tabla(sql):
    cols, filas = consulta(sql)
    return {"cols": cols, "rows": filas}


def main():
    plantilla, destino = sys.argv[1], sys.argv[2]
    D = {}
    cols, filas = consulta("SELECT * FROM v_kpi_ejecutivo")
    D["kpi"] = dict(zip(cols, filas[0])) if filas else {}
    D["mapa"] = tabla("""SELECT square_id, ROUND(lat, 5) lat, ROUND(lon, 5) lon, segmento, hora_pico,
                           ROUND(trafico_hora_pico, 3) tp, indice_presion ip, es_hotspot hs,
                           horas_elegibles_semana he
                         FROM v_mapa_cuadrantes WHERE cluster >= 0""")
    D["diario"] = tabla("SELECT dt, dow, es_festivo, internet, voz, pct_internacional FROM diario_ciudad ORDER BY dt")
    D["calor"] = tabla("SELECT dow, hora, SUM(internet_media) v FROM perfil_semanal GROUP BY dow, hora")
    D["cperf"] = tabla("""SELECT p.cluster, v.etiqueta, p.tipo_dia, p.hora, ROUND(p.valor_norm, 4) v
                          FROM cluster_perfil p JOIN v_cluster v USING (cluster)
                          ORDER BY p.cluster, p.tipo_dia, p.hora""")
    D["seg"] = tabla("SELECT * FROM v_ahorro_por_segmento ORDER BY cuadrantes DESC")
    D["eventos"] = tabla("""SELECT dt, hora, cuadrantes_anomalos, ROUND(z_max, 1) z_max
                            FROM evento_ciudad ORDER BY dt, hora""")
    D["dq"] = tabla("""SELECT control, valor, umbral, estado, severidad FROM dq_resultado
                       WHERE evaluado_en = (SELECT MAX(evaluado_en) FROM dq_resultado)
                       ORDER BY severidad, control""")
    _, filas = consulta("SELECT parametro, valor FROM param_roi")
    D["param"] = {f[0]: f[1] for f in filas}

    # Perfil semanal (168 horas) de cada hotspot, para el detalle al hacer clic
    _, filas = consulta("""SELECT p.square_id, p.dow, p.hora, p.internet_media
                           FROM perfil_semanal p JOIN cuadrante c USING (square_id)
                           WHERE c.es_hotspot""")
    perfiles = defaultdict(lambda: [0.0] * 168)
    for sq, dow, hora, v in filas:
        perfiles[sq][(dow - 1) * 24 + hora] = round(v or 0.0, 3)
    D["perfilHot"] = {str(k): v for k, v in perfiles.items()}

    # % de cuadrantes con ventana de ahorro activa en cada hora de la semana (total y por segmento)
    _, filas = consulta("""SELECT v.inicio_how, v.duracion_h, m.segmento
                           FROM ventana_ahorro v JOIN v_mapa_cuadrantes m USING (square_id)
                           WHERE m.cluster >= 0""")
    conteo = defaultdict(lambda: [0] * 168)
    for ini, dur, seg in filas:
        for h in range(ini, min(ini + dur, 168)):
            conteo[seg][h] += 1
            conteo["Todos"][h] += 1
    n_seg = defaultdict(int)
    i_seg = D["mapa"]["cols"].index("segmento")
    for f in D["mapa"]["rows"]:
        n_seg[f[i_seg]] += 1
        n_seg["Todos"] += 1
    D["ventanas"] = {s: [round(100 * x / n_seg[s], 2) if n_seg[s] else 0 for x in conteo[s]] for s in n_seg}
    D["generado"] = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%d %H:%M UTC")

    datos = json.dumps(D, ensure_ascii=False, separators=(",", ":")).replace("</", "<\\/")
    html = open(plantilla, encoding="utf-8").read().replace("/*__DATOS__*/null", datos, 1)
    with open(destino, "w", encoding="utf-8") as fh:
        fh.write(html)
    print(f"Tablero generado: {destino} ({len(html) / 1e6:.1f} MB, {len(D['mapa']['rows'])} cuadrantes)")


if __name__ == "__main__":
    main()
