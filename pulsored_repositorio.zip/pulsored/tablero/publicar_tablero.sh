#!/usr/bin/env bash
# PulsoRed | Publica el tablero como enlace publico (solo el HTML, nunca el lago de datos).
# Crea un bucket aparte con lectura publica, sube resultados/tablero_pulsored.html e imprime la URL.
# Se ejecuta en CLOUD SHELL despues de tablero/generar_tablero.sh.
#   bash tablero/publicar_tablero.sh            -> publica o actualiza (la URL no cambia)
#   bash tablero/publicar_tablero.sh retirar    -> deja de compartirlo
set -euo pipefail
cd "$(dirname "$0")/.."
PROYECTO="${PROYECTO:?Primero: export PROYECTO=tu-id-de-proyecto}"
PUB="gs://${PROYECTO}-pulsored-publico"
if [[ "${1:-}" == "retirar" ]]; then
  gcloud storage rm "$PUB/tablero_pulsored.html" && echo "Tablero retirado."; exit 0
fi
[[ -f resultados/tablero_pulsored.html ]] || { echo "Primero genera el tablero: bash tablero/generar_tablero.sh"; exit 1; }
if ! gcloud storage buckets describe "$PUB" >/dev/null 2>&1; then
  gcloud storage buckets create "$PUB" --location=us-central1 --uniform-bucket-level-access
  gcloud storage buckets update "$PUB" --no-public-access-prevention 2>/dev/null || true
  gcloud storage buckets add-iam-policy-binding "$PUB" --member=allUsers --role=roles/storage.objectViewer >/dev/null \
    || { echo "Tu organizacion no permite enlaces publicos: comparte el archivo HTML directamente."; exit 1; }
fi
gcloud storage cp resultados/tablero_pulsored.html "$PUB/" --cache-control="no-cache" --quiet
echo "Enlace para compartir: https://storage.googleapis.com/${PROYECTO}-pulsored-publico/tablero_pulsored.html"
